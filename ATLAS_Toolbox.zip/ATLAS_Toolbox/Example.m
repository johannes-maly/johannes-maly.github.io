%Example to demonstrate usage of ATTILA code

%% Parameters

alpha = 0.5;
beta = 0.5;

n1 = 16;
n2 = 100;

m = 90;
sparsity = 0.1;
rank = 1;
noiseLevel = 0.2;
normX = 10;

N0 = 50;
ISTAtolerance = 1e-8;


%% Create X with sparse right singular vectors to be recovered (with or without common support)

X = createSparseRandomLowRankInput(n1,n2,rank,sparsity);
%X = createSparseRandomLowRankInputCommonSupport(n1,n2,rank,sparsity);
X = (X/norm(X,'fro'));
X = X*normX;


%% Measurement matrix and measurements

A = randn(m,n1*n2)/(m^0.5);
y = A*X(:);
eps = rand(length(y),1);
eps = eps*noiseLevel*normX/norm(eps);
y = (y+eps);


%% Create start values by taking the singular vector pairs of the rank(X) leading singular values of A'*y

[u0,v0] = StartValue(y,A,n1,n2,rank);


%% Recover X

[U,V] = ATLAS_SIMULATIONVERSION(y,A,alpha,beta,u0,v0,N0,rank,ISTAtolerance);


%% Check results (error relative to Frobenius norm of X)

Error = norm(X-U*V','fro')/normX
