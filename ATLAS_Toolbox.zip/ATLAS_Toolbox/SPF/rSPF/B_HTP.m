function [ X ] = B_HTP( Phi,y,s,dx1,dx2,N0 )
%B Summary of this function goes here
%   Detailed explanation goes here

    X = zeros(dx1,dx2);
    nX = zeros(dx1,1);
    
    for k = 1:N0
        
        %Residual
        Xtemp = X + reshape(Phi'*(y-Phi*X(:)),dx1,dx2);
        
        %find indices of the s largest rows in norm of Xtemp
        for l = 1:dx1
            
            nX(l) = norm(Xtemp(l,:),2);
            
        end
        [b,I] = sort(nX,'descend');
        J = sort(I(1:s));
        
        %solve LeastSquares on support J
        X = LeastSquares(Phi,y,J,dx1,dx2);
        
    end

end

