function [ U,V ] = rSPF( A,y,n1,n2,r,s1,s2,U0,V0,N0 )
%RSPF Summary of this function goes here
%   Detailed explanation goes here

    U = U0;
    V = V0;

    for t = 1:N0
        
        V = orth(V);
        %if size(V0,2) > size(V,2)
        %    V = [V zeros(size(V0,1),size(V0,2)-size(V,2))];
        %end
        F = getFr(A,V);
        if s1*n1 < n1
            
            U = B_HTP(F,y,floor(s1*n1),n1,r,N0);
            
        else
            
            U = LeastSquares(F,y,1:n1,n1,r);
            
        end
        
        U = orth(U);
        %if size(U0,2) > size(U,2)
        %    U = [U zeros(size(U0,1),size(U0,2)-size(U,2))];
        %end
        G = getGr(A,U);
        if s2*n2 < n2
            
            V = B_HTP(G,y,floor(s2*n2),n2,r,N0);
            
        else
            
            V = LeastSquares(G,y,1:n2,n2,r);
            
        end 
        
    end

end

