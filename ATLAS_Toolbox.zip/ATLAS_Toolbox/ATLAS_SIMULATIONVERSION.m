function [ U,V ] = ATLAS_SIMULATIONVERSION( y,A,alpha,beta,u0,v0,N0,rank,ISTAtol )
%   ATLAS implementation following "..." for right sparse singular vectors
%   
%   y           -       Vector of measurements obtained as A*X(:)
%   A           -       Measurement matrix of dimension m x (n1*n2)
%   alpha,beta  -       Parameters of LRAS
%   [u0,v0]     -       Initialization
%   N0          -       Number of iterations
%   rank        -       Rank of unknown matrix to be recovered
%   ISTAtol     -       Tolerance of ISTA as LASSO solver (Default: 1e-8)

    n1 = size(u0,1);
    n2 = size(v0,1);
    m = length(y);
    
    U = zeros(n1,rank);
    V = zeros(n2,rank);
    
    u = u0;
    v = v0;

    %Iterating the Alternating Minimization
    for k = 1:N0
        
        %Doing the k-th AM step for the pair (u_r,v_r)
        for r = 1:rank
            
            %Creating temporary measurement
            y_temp = y;
            B = zeros(n1,n2);
            
            %B contains the influence of all (u_t,v_t) , t \neq r on y
            for t = 1:rank
                
                if t ~= r
                    
                    B = B + u(:,t)*v(:,t)';
                    
                end
                
            end
            
            y_temp = y_temp - A*B(:);
            
            %Solve minimization for u_r explicitely if rest is fixed
            
            Hv = zeros(m,n1);
            for i = 1:m
                Hv(i,:) = (reshape(A(i,:),n1,n2)*v(:,r))';
            end
            u(:,r) = (alpha*diag(ones(n1,1)) + Hv'*Hv) \ (Hv'*y_temp);
            
            
            %Solve minimization for v_r by SoftThresholding if rest is
            %fixed
            
            Gu = zeros(m,n2);
            for i = 1:m
                Gu(i,:) = u(:,r)'*reshape(A(i,:),n1,n2);
            end
            s = norm(Gu);
            v(:,r) = IterativeSoftThresholding(y_temp/s,Gu/s,zeros(n2,1),beta(1)/(2*s^2),ISTAtol);
            
        end
        
    end
    
    %Sort the vector pairs in decreasing order
    
    for r = 1:rank
        
        s(r,1) = norm(u(:,r))*norm(v(:,r));
        
    end
    
    [s,index] = sort(s,'descend');
    
    for r = 1:rank
        
        if norm(v(:,index(r))) ~= 0 && norm(u(:,index(r))) ~= 0
            
            U(:,r) = u(:,index(r));%/norm(u(:,index(r)));
            V(:,r) = v(:,index(r));%/norm(v(:,index(r)));

        else

            U(:,r) = u(:,r) * 0;
            V(:,r) = v(:,r) * 0;

        end
        
    end
    
end

