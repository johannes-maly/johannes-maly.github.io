README 

Matlab Code for ATLAS simulation and test files (supplementary material for “A-T-LAS_{2,1}: A Multi-Penalty Approach to Compressed Sensing of Low-Rank Matrices with Sparse Decompositions” by M. Fornasier, J. Maly, V. Naumova)

@author: Johannes Maly

Short Description:

ATLAS_Toolbox contains the main algorithm “ATLAS_SIMULATIONVERSION.m” and a basic HOW-TO-USE example “Example.m” which can be directly executed.

The folders “Tools” and “ISTA” contain some auxiliary files and the Iterative Soft-Thresholding Algorithm.

“SPF” contains an implementation of the so-called Sparse Power Factorization (for further information check the paper and included references) and a basic HOW-TO-USE example “SPFTest.m” which can be directly executed.

All paper related experiments are collected in “Paper_ATLAS_Simulations”. The “TEST_XXX.m”-files are the executable test-files. The “PLOT_XXX.m”-files can be used to plot the corresponding data which is stored in “DATA_XXX.mat”-files. All figures are included as “XXX.png”-files as well.
The real-life data experiments are in the subfolder FaceData_Simulation. There is one file 

Have fun:)

Please report any issues to maly@mathc.rwth-aachen.de


