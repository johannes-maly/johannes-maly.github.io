function [ result ] = SoftThresholdingOperator( u,alpha )
%SOFTTHRESHOLDINGOPERATOR Summary of this function goes here
%   Detailed explanation goes here

    [du1,du2] = size(u);
    result = zeros(du1,1);
    
    if du2 ~= 1
        
        error('u must be vector!');
        
    end
    
    for i = 1:du1
        
        if u(i,1) > alpha
            
            result(i,1) = u(i,1)-alpha;
            
        elseif u(i,1) < -alpha
            
            result(i,1) = u(i,1)+alpha;
            
        else
            
            result(i,1) = 0;
            
        end
        
    end        
    

end

