function [ v ] = IterativeSoftThresholding( y,A,v0,beta,tolerance )
%	Iterative Thresholding
%   Detailed explanation goes here

    v_old = v0;
    M = A'*A;
    
    for i = 1:10000000
        %beta=beta*0.95;
        v = SoftThresholdingOperator(v_old + A'*y - M*v_old,beta);
        
        if norm(v-v_old) < tolerance
            
            %i
            break;
            
        end
        
        v_old = v;
        
    end


end

