
load('DATA_Figure4_alpha=0,01beta.mat')

fontSize = 25;
lineWidth = 3;

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
hold on

plot(bRange,Error,'b',bRange,ErrorBound,'--r','LineWidth',lineWidth);
plot(bRange,SupportSizeVab,'-o','Color',[1 0.7 0],'MarkerFaceColor',[1 0.7 0],'LineWidth',0.6*lineWidth)

axis([bRange(length(bRange)) bRange(1) 0 1]);
xlabel('Beta','FontSize',fontSize);
ylabel('Relative Error / Relative Sparsity','FontSize',fontSize);
set(gca,'FontSize',fontSize)
grid on