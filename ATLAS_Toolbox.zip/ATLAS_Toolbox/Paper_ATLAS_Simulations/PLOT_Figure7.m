
load('DATA_Figure7_Rank1.mat')

fontSize = 25;


f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 1.5, 0.6]); 
colorbar

%Figure 1 - large Deviation
% f = figure;
% set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
subplot(1,3,1)
image([0.05 0.5],[0.05 1],ProbForSuccRecINITlargeDIST(1:20,1:10),'CDataMapping','scaled')
%colorbar
xlabel('s/n_2','FontSize',fontSize)
ylabel('m/(n_1n_2)','FontSize',fontSize)
set(gca,'FontSize',fontSize)
set(gca,'Ydir','Normal')

%Figure 2 - Transpose
subplot(1,3,2)
image([0.05 0.5],[0.05 1],ProbForSuccRecINITtranspose(1:20,1:10),'CDataMapping','scaled')
%colorbar
xlabel('s/n_2','FontSize',fontSize)
ylabel('m/(n_1n_2)','FontSize',fontSize)
set(gca,'FontSize',fontSize)
set(gca,'Ydir','Normal')


%Figure 3 - small Deviation
% f = figure;
% set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
subplot(1,3,3)
image([0.05 0.5],[0.05 1],ProbForSuccRecINITsmallDIST(1:20,1:10),'CDataMapping','scaled')
%colorbar
xlabel('s/n_2','FontSize',fontSize)
ylabel('m/(n_1n_2)','FontSize',fontSize)
set(gca,'FontSize',fontSize)
set(gca,'Ydir','Normal')