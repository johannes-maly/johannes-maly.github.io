%Simulation scenario to compare ATLAS to SPF (GREYSCALE PLOT)

%% Parameters

SuccessThreshold = 0.4;             %Error in % of norm(X) to call approximation successful

dx1 = 4;
dx2 = 128;
rank = 1;

alpha = 0.5;
beta = 0.5;

sparsity = 0.05:0.05:1;
m = 0.05:0.05:1;

NrMeas  = floor(m*dx1*dx2);
NrOfX   = 30;
ErrorMatrixSPF = zeros(length(NrMeas),length(sparsity),NrOfX);
ErrorMatrixATLAS = zeros(length(NrMeas),length(sparsity),NrOfX);

N0 = 50;
normOfX = 10;
noise = 0.3;                        %Noise Level

IS_RECOVERY_ALREADY_SAFE = zeros(length(sparsity),1);

%% Create Measurements

for k = 1:length(NrMeas)
    
    A = randn(NrMeas(k),dx1*dx2)/(NrMeas(k)^0.5);
    
    %% Iterate Sparsity
    
    for s = 1:length(sparsity)
    
        if IS_RECOVERY_ALREADY_SAFE(s) == 0
            
            %% Create X and y (with noise)
            for l = 1:NrOfX        

                [k s l]

                X = createSparseRandomLowRankInputCommonSupport(dx1,dx2,rank,sparsity(s));
                %X = createSparseRandomLowRankInput(dx1,dx2,rank,sparsity(s));
                nrmX = norm(X,'fro');
                X = X*normOfX/nrmX;
                y = A*X(:);
                eps = randn(NrMeas(k),1); eps = (eps/norm(eps))*(normOfX*noise);
                y = y + eps;

                %% Initialize and Recover with SPF and ATLAS

                [U0,V0] = StartValue(y,A,dx1,dx2,rank);
                [Uspf,Vspf] = rSPF(A,y,dx1,dx2,rank,1,sparsity(s),U0,V0,N0);

                [Uatlas,Vatlas] = ATLAS_SIMULATIONVERSION(y,A,alpha,beta,U0,V0,N0,rank,1e-8);

                %% Update Error Matrices

                ErrorMatrixSPF(k,s,l) = norm(X-Uspf*Vspf','fro')/norm(X,'fro');
                ErrorMatrixATLAS(k,s,l) = norm(X-Uatlas*eye(dx1,dx2)*Vatlas','fro')/norm(X,'fro');

            end
            
            if (k > 3) && (max(max(sum(ErrorMatrixSPF((k-3):k,s,:) >= SuccessThreshold,3))) == 0) && (max(max(sum(ErrorMatrixATLAS((k-3):k,s,:) >= SuccessThreshold,3))) == 0)
        
                IS_RECOVERY_ALREADY_SAFE(s) = 1;
            
            end
            
        else
            
            ErrorMatrixSPF(k,s,:) = zeros(NrOfX,1);
            ErrorMatrixATLAS(k,s,:) = zeros(NrOfX,1);
            
        end
            
    end
    
end

%% Data Processing

ProbForSuccRecSPF = sum(ErrorMatrixSPF < SuccessThreshold,3)/NrOfX;
ProbForSuccRecATLAS = sum(ErrorMatrixATLAS < SuccessThreshold,3)/NrOfX;

AverageErrorSPF = sum(ErrorMatrixSPF,3)./NrOfX;
AverageErrorATLAS = sum(ErrorMatrixATLAS,3)./NrOfX;

save('DATA_Figure2.mat')
