
load('DATA_Figure1_CommonSupport.mat')

fontSize = 25;
lineWidth = 3;

AvErSPF = AverageErrorSPF;
AvErATLAS = AverageErrorATLAS;
PrSuSPF = ProbForSuccRecSPF;
PrSuATLAS = ProbForSuccRecATLAS;

load('DATA_Figure1_ArbitrarySupport.mat')

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]);
%set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 1.0, 0.6]);

%subplot(2,1,1)
hold on
plot(NrMeas,AvErSPF,'--r',NrMeas,AvErATLAS,'b','LineWidth',lineWidth)
plot(NrMeas,AverageErrorSPF,'--g',NrMeas,AverageErrorATLAS,'c','LineWidth',lineWidth)
xlabel('Number of Measurements','FontSize',fontSize)
ylabel('Relative Error','FontSize',fontSize);
axis([NrMeas(1) NrMeas(length(NrMeas)) 0 1])
set(gca,'FontSize',fontSize)
grid on

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]);

%subplot(2,1,2)
hold on
plot(NrMeas,PrSuSPF,'--r',NrMeas,PrSuATLAS,'b','LineWidth',lineWidth)
plot(NrMeas,ProbForSuccRecSPF,'--g',NrMeas,ProbForSuccRecATLAS,'c','LineWidth',lineWidth)
xlabel('Number of Measurements','FontSize',fontSize)
ylabel('Recovery Probability','FontSize',fontSize);
axis([NrMeas(1) NrMeas(length(NrMeas)) 0 1])
set(gca,'FontSize',fontSize)
grid on

% load('TestLRASvsSPFNoisefinal.mat')
% 
% subplot(1,2,1)
% plot(NrMeas,AverageErrorSPF,'--g',NrMeas,AverageErrorLRAS,'c','LineWidth',lineWidth)
% 
% subplot(1,2,2)
% plot(NrMeas,ProbForSuccRecSPF,'--g',NrMeas,ProbForSuccRecLRAS,'c','LineWidth',lineWidth)