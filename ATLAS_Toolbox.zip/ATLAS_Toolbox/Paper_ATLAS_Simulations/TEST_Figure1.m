%Simulation scenario to compare LRAS to SPF for common/arbitrary support

%% Parameters

SuccessThreshold = 0.4; %Error in % of norm(X) to call approximation successful

dx1 = 16;
dx2 = 100;
rank = 5;

alpha = 0.5;
beta = 0.5;

s = 0.1;

NrMeas  = rank*[20:10:150];
NrOfX   = 30;
ErrorMatrixSPF = zeros(NrOfX,length(NrMeas));
ErrorMatrixATLAS = zeros(NrOfX,length(NrMeas));

N0 = 50;
normOfX = 10;
noise = 0.3;

%% Create Measurements

for k = 1:length(NrMeas)
    
    A = randn(NrMeas(k),dx1*dx2)/(NrMeas(k)^0.5);
    
    %% Create X and y (with noise)
    
    for l = 1:NrOfX        
        
        [k l]
        
        X = createSparseRandomLowRankInputCommonSupport(dx1,dx2,rank,s);    %Common Support
        %X = createSparseRandomLowRankInput(dx1,dx2,rank,s);                 %Arbitrary Support
        
        nrmX = norm(X,'fro');
        X = X*normOfX/nrmX;
        y = A*X(:);
        eps = randn(NrMeas(k),1); eps = (eps/norm(eps))*(normOfX*noise);
        y = y + eps;
        
        %% Initialize and Recover with SPF and ATLAS
        
        [U0,V0] = StartValue(y,A,dx1,dx2,rank);
        [Uspf,Vspf] = rSPF(A,y,dx1,dx2,rank,1,s,U0,V0,N0);                  %Common Support
        %[Uspf,Vspf] = rSPF(A,y,dx1,dx2,rank,1,rank*s,U0,V0,N0);             %Arbitrary Support
        
        [Uatlas,Vatlas] = LRAS_SIMULATIONVERSION(y,A,alpha,beta,U0,V0,N0,rank,1e-8);
        
        %% Update Error Matrices
        
        ErrorMatrixSPF(l,k) = norm(X-Uspf*Vspf','fro')/norm(X,'fro');
        ErrorMatrixATLAS(l,k) = norm(X-Uatlas*eye(dx1,dx2)*Vatlas','fro')/norm(X,'fro');
    
    end
end

%% Data Processing

ProbForSuccRecSPF = sum(ErrorMatrixSPF < SuccessThreshold)/NrOfX;
ProbForSuccRecATLAS = sum(ErrorMatrixATLAS < SuccessThreshold)/NrOfX;

AverageErrorSPF = sum(ErrorMatrixSPF)./NrOfX;
AverageErrorATLAS = sum(ErrorMatrixATLAS)./NrOfX;

save('DATA_Figure1.mat')

        