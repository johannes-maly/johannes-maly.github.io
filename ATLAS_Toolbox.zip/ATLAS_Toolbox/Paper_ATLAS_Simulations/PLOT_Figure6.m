
load('DATA_Figure2_noise.mat')

fontSize = 25;
lineWidth = 3;

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
hold on

%Levels of SPF
contour(0.05:0.05:1,0.05:0.05:1,ProbForSuccRecSPF,[0.3 0.3],'--y','LineWidth',lineWidth)
contour(0.05:0.05:1,0.05:0.05:1,ProbForSuccRecSPF,[0.7 0.7],'--b','LineWidth',lineWidth)
contour(0.05:0.05:1,0.05:0.05:1,ProbForSuccRecSPF,[0.9 0.9],'--r','LineWidth',lineWidth)

%Levels of ATLAS
contour(0.05:0.05:1,0.05:0.05:1,ProbForSuccRecATLAS,[0.3 0.3],'y','LineWidth',lineWidth)
contour(0.05:0.05:1,0.05:0.05:1,ProbForSuccRecATLAS,[0.7 0.7],'b','LineWidth',lineWidth)
contour(0.05:0.05:1,0.05:0.05:1,ProbForSuccRecATLAS,[0.9 0.9],'r','LineWidth',lineWidth)

xlabel('s/n_2','FontSize',fontSize)
ylabel('m/(n_1n_2)','FontSize',fontSize);
set(gca,'FontSize',fontSize)
grid on