load('DATA_Figure5.mat')

fontSize = 25;
lineWidth = 3;

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 

plot(normX,Error(:,j),'b',normX,ErrorBound,'--r','LineWidth',lineWidth);

axis([normX(1) normX(length(normX)) 0 1]);
xlabel('Norm of X','FontSize',fontSize);
ylabel('Relative Error','FontSize',fontSize);
set(gca,'FontSize',fontSize)
grid on