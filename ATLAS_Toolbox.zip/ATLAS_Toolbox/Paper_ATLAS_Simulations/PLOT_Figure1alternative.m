
load('DATA_Figure1_CommonSupport.mat')

fontSize = 25;
lineWidth = 3;

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 1.0, 0.6]); 

subplot(1,2,1)
plot(NrMeas,AverageErrorSPF,'--r',NrMeas,AverageErrorATLAS,'b','LineWidth',lineWidth)
xlabel('Number of Measurements','FontSize',fontSize)
ylabel('Relative Error','FontSize',fontSize);
axis([NrMeas(1) NrMeas(length(NrMeas)) 0 1])
set(gca,'FontSize',fontSize)
grid on

subplot(1,2,2)
plot(NrMeas,ProbForSuccRecSPF,'--r',NrMeas,ProbForSuccRecATLAS,'b','LineWidth',lineWidth)
xlabel('Number of Measurements','FontSize',fontSize)
ylabel('Recovery Probability','FontSize',fontSize);
axis([NrMeas(1) NrMeas(length(NrMeas)) 0 1])
set(gca,'FontSize',fontSize)
grid on