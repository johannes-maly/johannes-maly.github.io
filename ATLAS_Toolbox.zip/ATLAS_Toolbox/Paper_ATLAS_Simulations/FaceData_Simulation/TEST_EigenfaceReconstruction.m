clear all

% Comparison of ATLAS and SPF on non-synthetic data
%
%   X            -         Data matrix whose 'numberOfImages' rows are the Wavelet
%                          coefficients of Images in Test_Images rescaled
%                          to size 'imageDimension'
%   A            -         Gaussian measurement operator
%   y            -         Measurements of X via A
%   X_SPF        -         Rank-1 reconstruction of X via SPF
%   X_ATLAS      -         Rank-1 redonstruction of X via ATLAS
%

filename = 'DATA/ImageComparisonData/TEST_HR_NoNoise_R0+3_OF20_db3';

% Parameters

numberOfImages = 10;                            % Max nr. 15
imageDimension = round(2*[32,22]);              % Height x Length
wName = 'db3';                                  % Mother Wavelet, e.g., 'db1' (Haar), 'bior3.7'
wDepth = wmaxlev(imageDimension,wName);         % Depth of Wavelet transform

numberOfPerturbedRows = 0;                      % Number of rows of X with randomly permuted entries to 
                                                % increase effective rank and destroy
                                                % common support structure
                                
rankOverestimation = 3;                         % Overestimation of effective Rank, i.e. R
                                                % for ATLAS and SPF is effective Rank + rankOverestimation
                                
equalizeSV = false;                             % Shall leading singular values be made equal?

rng(2)                                          % Fix Random Generator

alphaGrid = [0.5 0.1 0.05 0.01 0.005];%[10 5 1 0.5 0.1 0.05 0.01];%[1 0.5 0.1 0.05 0.01 0.005];
betaGrid = [0.01 0.005 0.001];%[0.05 0.01 0.005];%alphaGrid/10;
sGrid = [100:10:300];
noiseLevel = 0.0;
oversampling_Factor = 20;
normX = 1;

ErrorSPF = zeros(length(sGrid),2);
MeasurementMisfitSPF = zeros(length(sGrid),1);
RecoveryTimeSPF = zeros(length(sGrid),1);
ErrorATLAS = zeros(length(alphaGrid),length(betaGrid),2);
MeasurementMisfitATLAS = zeros(length(alphaGrid),length(betaGrid));
SparsityATLAS = zeros(length(alphaGrid),length(betaGrid),2);
RecoveryTimeATLAS = zeros(length(alphaGrid),length(betaGrid));


% Extract images and construct X from Wavelet coefficients

[Images,Coeff,S] = prepareImages(numberOfImages, imageDimension, wName, wDepth);
for k = 1:numberOfPerturbedRows
   key(:,k) = randperm(size(Coeff,1));
   Coeff(:,k) = Coeff(key(:,k),k);
   InvKey(:,k) = 1:size(key,1);
   InvKey(key(:,k),k) = InvKey(:,k);
end
X = Coeff';
X = normX*X/norm(X,'fro');

% Extract structural setting

[n_1,n_2] = size(X);
sparsity = ceil(max((vecnorm(X,1,2)./vecnorm(X,2,2)).^2));
Rank = ceil(norm(svd(X),1)/norm(svd(X),Inf)) + rankOverestimation;
%Rank = floor((norm(svd(X),1)/norm(svd(X),2))^2) + rankOverestimation;

% Enforce leading singular values to be of equal size

if equalizeSV == true
    [U,Sigma,V] = svd(X);
    Sigma(1:Rank,1:Rank) = eye(Rank);
    X = U*Sigma*V';
    X = normX*X/norm(X,'fro');
    sparsity = ceil(max((vecnorm(X,1,2)./vecnorm(X,2,2)).^2));
    Rank = floor((norm(svd(X),1)/norm(svd(X),2))^2) + rankOverestimation;
end

U_Solutions_SPF = zeros(n_1,Rank,length(sGrid));
V_Solutions_SPF = zeros(n_2,Rank,length(sGrid));
U_Solutions_ATLAS = zeros(n_1,Rank,length(alphaGrid),length(betaGrid));
V_Solutions_ATLAS = zeros(n_2,Rank,length(alphaGrid),length(betaGrid));

measurements = oversampling_Factor*Rank*(sparsity+n_1);

% Construct measurement matrix and measurements

A = randn(measurements,n_1*n_2)/sqrt(measurements);

eta = rand(measurements,1);
eta = noiseLevel*norm(X,'fro')*eta/norm(eta);
y = A*X(:) + eta;

% Recover X via SPF and ATLAS on parameter grid

N0 = 50;
ISTAtolerance = 1e-8;
%U0 = eye(n_1);
% V0 = X';
[U0,V0] = StartValue(y,A,n_1,n_2,Rank);

for a = 1:length(alphaGrid)
    for b = 1:length(betaGrid)
        %b = a;
        
        [2 a b]
        
        tic
        [U_ATLAS,V_ATLAS] = ATLAS_SIMULATIONVERSION(y,A,alphaGrid(a),betaGrid(b),U0,V0,N0,Rank,ISTAtolerance);
        RecoveryTimeATLAS(a,b) = toc;
        
        X_ATLAS = U_ATLAS*V_ATLAS';
        
        ErrorATLAS(a,b,1) = norm(X_ATLAS - X,'fro')/norm(X,'fro');
        ErrorATLAS(a,b,2) = acos( trace( X' * X_ATLAS ) / ( norm(X,'fro')*norm(X_ATLAS,'fro') ) );
        MeasurementMisfitATLAS(a,b) = norm(A*X_ATLAS(:) - y,'fro')/norm(X,'fro');
        SparsityATLAS(a,b,1) = nnz(U_ATLAS*V_ATLAS');
        SparsityATLAS(a,b,2) = (norm(V_ATLAS,1)/norm(V_ATLAS,2))^2;
        
        U_Solutions_ATLAS(:,:,a,b) = U_ATLAS;
        V_Solutions_ATLAS(:,:,a,b) = V_ATLAS;
        
    end
end

for s = 1:length(sGrid)
    
    [1 s]
    
    tic
    [U_SPF,V_SPF] = rSPF(A,y,n_1,n_2,Rank,1,sGrid(s)/n_2,U0,V0,N0);
    RecoveryTimeSPF(s) = toc;
    
    X_SPF = U_SPF*V_SPF';
    
    ErrorSPF(s,1) = norm(X_SPF - X,'fro')/norm(X,'fro');
    ErrorSPF(s,2) = acos( trace( X' * X_SPF ) / ( norm(X,'fro')*norm(X_SPF,'fro') ) );
    MeasurementMisfitSPF(s) = norm(A*X_SPF(:) - y,'fro')/norm(X,'fro');
    
    U_Solutions_SPF(:,:,s) = U_SPF;
    V_Solutions_SPF(:,:,s) = V_SPF;
    
        
end

clear A;
save(filename)

% Output Data

[sGrid' ErrorSPF MeasurementMisfitSPF RecoveryTimeSPF]
ErrorATLAS(:,:,1)
MeasurementMisfitATLAS
RecoveryTimeATLAS
SparsityATLAS(:,:,1)
SparsityATLAS(:,:,2)



%% Supplementary Functions

function [Images,Coeff,S] = prepareImages(numberOfImages, imageDimension, wName, wDepth)

    % size(s) = (wDepth+2) x 2

    folder = 'Test_Images';
    extension = '.jpg';

    cd(folder)
    files = dir(strcat('*', extension));
    j = 1;

    for file = files'

        x = imread(file.name);
        p = imresize(x, imageDimension); 
        p = rgb2gray(p);
        p = im2double(p);

        [c,s] = wavedec2(p,wDepth,wName);
        %pRec = waverec2(c,s,wName);
        
        Images(:,j) = p(:);
        Coeff(:,j) = c;
        S(:,j) = s(:);
        
        if j == numberOfImages
            break;
        else
            j = j+1;
        end

    end
    
    cd ..
        
end