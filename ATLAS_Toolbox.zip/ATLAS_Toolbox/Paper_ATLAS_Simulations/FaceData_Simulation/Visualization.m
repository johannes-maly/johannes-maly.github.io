clear all
load('DATA/ImageComparisonData/TEST_HR_NoNoise_R0+3_OF20.mat')

% Choose whether the parameters for SPF and ATLAS shall be determined via
% DiscrepancyPrinciple or BestApproximation
discrepancyPrinciple = false;

if discrepancyPrinciple

    % Parameter choice via DISCREPANCY PRINCIPLE
    [min_a, a] = min(min(abs(MeasurementMisfitATLAS - noiseLevel)'));
    [min_b, b] = min(min(abs(MeasurementMisfitATLAS - noiseLevel)));
    [min_s, s] = min(abs(MeasurementMisfitSPF - noiseLevel));
    
    
    min_b = ErrorATLAS(a,b,1);
    min_s = ErrorSPF(s,1);
    
else
    
    % Parameter choice via BEST APPROXIMATION
    [min_a, a] = min(min(squeeze(ErrorATLAS(:,:,1))'));
    [min_b, b] = min(min(ErrorATLAS(:,:,1)));
    [min_s, s] = min(ErrorSPF(:,1));

end

% Extract solutions

[U,Sigma,V] = svd(X);
U_ATLAS = U_Solutions_ATLAS(:,:,a,b);
V_ATLAS = V_Solutions_ATLAS(:,:,a,b);
X_ATLAS = U_ATLAS*V_ATLAS';
U_SPF = U_Solutions_SPF(:,:,s);
V_SPF = V_Solutions_SPF(:,:,s);
X_SPF = U_SPF*V_SPF';

% Output Data

[sGrid' ErrorSPF MeasurementMisfitSPF]
ErrorATLAS(:,:,1)
MeasurementMisfitATLAS
RecoveryTimeATLAS
SparsityATLAS(:,:,1)
SparsityATLAS(:,:,2)

[U,Sigma,V] = svd(X);
X_trunc = U(:,1:Rank)*Sigma(1:Rank,1:Rank)*V(:,1:Rank)';

SPFvsATLASvsSVD = [min_s min_b norm(X-X_trunc,'fro')/norm(X,'fro')]



% Show all Faces (= rows of X) to compare outcome

for k = 1:n_1
    
    if k <= numberOfPerturbedRows
        pRec_Original = waverec2(X(k,InvKey(:,k))/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_SPF = waverec2(X_SPF(k,InvKey(:,k))/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_ATLAS = waverec2(X_ATLAS(k,InvKey(:,k))/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
    else
        pRec_Original = waverec2(X(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_SPF = waverec2(X_SPF(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_ATLAS = waverec2(X_ATLAS(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
    end
    figure
    subplot(1,4,1);%3*k-2)
    imshow(pRec_Original, [min(min(pRec_Original)) max(max(pRec_Original))])
    title('Original')
    subplot(1,4,2);%3*k-1)
    imshow(pRec_SPF, [min(min(pRec_SPF)) max(max(pRec_SPF))])
    title('SPF')
    subplot(1,4,3);%3*k)
    imshow(pRec_ATLAS, [min(min(pRec_ATLAS)) max(max(pRec_ATLAS))])
    title('ATLAS')
    
    if numberOfPerturbedRows == 0
        
        pRec_SVD = waverec2(X_trunc(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        subplot(1,4,4);%3*k)
        imshow(pRec_SVD, [min(min(pRec_SVD)) max(max(pRec_SVD))])
        title('Truncated SVD')
        
    end
    
end

% for k = [1 5]
%     
%     if k <= numberOfPerturbedRows
%         pRec_Original = waverec2(X(k,InvKey(:,k))/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_SPF = waverec2(X_SPF(k,InvKey(:,k))/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_ATLAS = waverec2(X_ATLAS(k,InvKey(:,k))/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%     else
%         pRec_Original = waverec2(X(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_SPF = waverec2(X_SPF(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_ATLAS = waverec2(X_ATLAS(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%     end
%     figure
%     imshow(pRec_Original, [min(min(pRec_Original)) max(max(pRec_Original))])
%     %title('Original')
%     figure
%     imshow(pRec_SPF, [min(min(pRec_SPF)) max(max(pRec_SPF))])
%     %title('SPF')
%     figure
%     imshow(pRec_ATLAS, [min(min(pRec_ATLAS)) max(max(pRec_ATLAS))])
%     %title('ATLAS')
%     
%     if numberOfPerturbedRows == 0
%         
%         pRec_SVD = waverec2(X_trunc(k,:)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         figure
%         imshow(pRec_SVD, [min(min(pRec_SVD)) max(max(pRec_SVD))])
%         %title('Truncated SVD')
%         
%     end
%     
% end

% Show first #Rank Eigenfaces (= right eigenvectors of X) to compare outcome

figure
for k = 1:Rank
    
    if k <= numberOfPerturbedRows
        pRec_Original = waverec2(V(InvKey(:,k),k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_SPF = waverec2(V_SPF(InvKey(:,k),k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_ATLAS = waverec2(-V_ATLAS(InvKey(:,k),k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
    else
        pRec_Original = waverec2(V(:,k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_SPF = waverec2(V_SPF(:,k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
        pRec_ATLAS = waverec2(-V_ATLAS(:,k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
    end
    subplot(Rank,3,3*k-2)
    imshow(pRec_Original,[min(min(pRec_Original)) max(max(pRec_Original))])
    title('Original')
    subplot(Rank,3,3*k-1)
    imshow(pRec_SPF,[min(min(pRec_SPF)) max(max(pRec_SPF))])
    title('SPF')
    subplot(Rank,3,3*k)
    imshow(pRec_ATLAS,[min(min(pRec_ATLAS)) max(max(pRec_ATLAS))])
    title('ATLAS')
    
end
    
% for k = 2
%     
%     if k <= numberOfPerturbedRows
%         pRec_Original = waverec2(V(InvKey(:,k),k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_SPF = waverec2(V_SPF(InvKey(:,k),k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_ATLAS = waverec2(-V_ATLAS(InvKey(:,k),k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%     else
%         pRec_Original = waverec2(V(:,k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_SPF = waverec2(V_SPF(:,k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%         pRec_ATLAS = waverec2(-V_ATLAS(:,k)/normX*norm(Coeff,'fro'),reshape(S(:,k),wDepth+2,2),wName);
%     end
%     figure
%     imshow(pRec_Original,[min(min(pRec_Original)) max(max(pRec_Original))])
%     %title('Original')
%     figure
%     imshow(pRec_SPF,[min(min(pRec_SPF)) max(max(pRec_SPF))])
%     %title('SPF')
%     figure
%     imshow(pRec_ATLAS,[min(min(pRec_ATLAS)) max(max(pRec_ATLAS))])
%     %title('ATLAS')
%     
% end
