
load('DATA_Figure2_noNoise.mat')

fontSize = 25;

%Figure 1 - SPF
f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
image([0.05 1],[0.05 1],ProbForSuccRecSPF,'CDataMapping','scaled')
colorbar
xlabel('s/n_2','FontSize',fontSize)
ylabel('m/(n_1n_2)','FontSize',fontSize)
set(gca,'FontSize',fontSize)
set(gca,'Ydir','Normal')


%Figure 2 - ATLAS
f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
image([0.05 1],[0.05 1],ProbForSuccRecATLAS,'CDataMapping','scaled')
colorbar
xlabel('s/n_2','FontSize',fontSize)
ylabel('m/(n_1n_2)','FontSize',fontSize)
set(gca,'FontSize',fontSize)
set(gca,'Ydir','Normal')