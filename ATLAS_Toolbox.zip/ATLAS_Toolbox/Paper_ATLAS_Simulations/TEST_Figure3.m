%Simulation scenario to test influence of noise level on ATLAS

%% Parameters

ISTAtolerance = [1e-8];
abRatio = 1;
noiseNrm = [0.1:0.05:0.7];

dimX1 = 16;
dimX2 = 100;
sparsity = 0.1;
rank = 5;                           %Rank R
measurements = 400;                 %Number of measurements
N0 = 50;
Error = zeros(length(noiseNrm),length(ISTAtolerance));

nrOfX = 100;
normX = 10; %Frobenius norm of X

%Measurement Matrix
A = randn(measurements,dimX1*dimX2)/(measurements^0.5);

%Bound on \| X - X_ab \|

s = sparsity*dimX2;             ss = s^(1/3);
C21 = (0.5)^(2/3) + 2^(1/3);

ErrorBound = (noiseNrm.*normX).*1.*(( C21.*ss + 2.^0.5 ).^0.5)./normX;


%% Recovery

for k = 1:length(noiseNrm)
    
    for l = 1:nrOfX
        
        [k l]

        %X
        X = createSparseRandomLowRankInput(dimX1,dimX2,rank,sparsity);
        X = (X/norm(X,'fro'));
        X = X*normX;
        SnormX = SchattenNorm(X,2/3);
        
        %Alpha, Beta
        beta = ((noiseNrm(k)*normX)/(SnormX^(1/3)))^2;

        %Measurements, Noise and Start Value
        y = A*X(:);
        eps = rand(length(y),1);
        eps = eps*noiseNrm(k)*normX/norm(eps);
        y = (y+eps);
        [u0,v0] = StartValue(y,A,dimX1,dimX2,rank);

        for j = 1:length(ISTAtolerance)

            [U,V] = ATLAS_SIMULATIONVERSION(y,A,beta*abRatio,beta,u0,v0,N0,rank,ISTAtolerance(j));
            Error(k,j) = Error(k,j) + norm(X-U*eye(dimX1,dimX2)*V','fro')/(normX);

        end
        
    end
    
end

Error = Error/nrOfX;

save('DATA_Figure3.mat')