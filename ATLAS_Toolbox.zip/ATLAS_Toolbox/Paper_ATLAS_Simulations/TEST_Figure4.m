%Simulation scenario to examine the influence of parameters alpha,beta on
%ATLAS


%% Parameters

abRatio = 1; %=alpha/beta
bRange = [1:-0.05:0.3, 0.26:-0.04:0.1, 0.09:-0.01:0.04 0.039:-0.002:0.02];

ISTAtolerance = [1e-8];

dimX1 = 16;
dimX2 = 100;
sparsity = 0.1;
rank = 1;
measurements = 90;
noiseNrm = 0.0;
N0 = 50;

normX = 10; %Frobenius norm of X

Error = zeros(length(bRange),length(ISTAtolerance));
SupportSizeVab = zeros(length(bRange),length(ISTAtolerance));
SupportBound = zeros(length(bRange),1);
ErrorBound = zeros(length(bRange),1);

%Measurement Matrix and X
A = randn(measurements,dimX1*dimX2)/(measurements^0.5);
X = createSparseRandomLowRankInputCommonSupport(dimX1,dimX2,rank,sparsity);
X = (X/norm(X,'fro'))*normX;

%Measurements, Noise and Start Value
y = A*X(:);
eps = rand(length(y),1);
eps = eps*noiseNrm*normX/norm(eps);
y = (y+eps);
[u0,v0] = StartValue(y,A,dimX1,dimX2,rank);

%Bound on \| y - A(uvT) \|
s = sparsity*dimX2;             ss = s^(1/3);
C21 = (0.5)^(2/3) + 2^(1/3);

ErrorBound = ( ( C21.*ss )^(0.5).*((bRange.^3.*abRatio).^(1/6)).*(SchattenNorm(X,2/3).^(1/3)))/normX;


%% Recovery

for k = 1:length(bRange)
    
    k
    
    for j = 1:length(ISTAtolerance)
        
        [U,V] = ATLAS_SIMULATIONVERSION(y,A,abRatio*bRange(k),bRange(k),u0,v0,N0,rank,ISTAtolerance(j));
        Error(k,j) = norm(X-U*eye(dimX1,dimX2)*V','fro')/normX;
        SupportSizeVab(k,j) = sum(V(:,1) >= 0.001)/dimX2;
        
    end
    
end

save('DATA_Figure4.mat')