%Simulation scenario to compare various initialization qualities for ATLAS (GREYSCALE PLOT)

%% Parameters

clear all

SuccessThreshold = 0.4; %Error in % of norm(X) to call approximation successful

dx1 = 8;
dx2 = 128;
rank = 1;               %Rank R

alpha = 0.5;
beta = 0.5;

sparsity = 0.05:0.05:1;
m = 0.05:0.05:1;

NrMeas  = floor(m*dx1*dx2);
NrOfX   = 20;
ErrorMatrixINITtranspose = zeros(length(NrMeas),length(sparsity),NrOfX);
ErrorMatrixINITlargeDIST = zeros(length(NrMeas),length(sparsity),NrOfX);
ErrorMatrixINITsmallDIST = zeros(length(NrMeas),length(sparsity),NrOfX);

N0 = 50;
normOfX = 10;
noise = 0.3;

IS_RECOVERY_ALREADY_SAFE = zeros(length(sparsity),1);

%% Create Measurements

for k = 1:length(NrMeas)
    
    A = randn(NrMeas(k),dx1*dx2)/(NrMeas(k)^0.5);
    
    %% Iterate Sparsity
    
    for s = 1:length(sparsity)
    
        if IS_RECOVERY_ALREADY_SAFE(s) == 0
            
            
            %% Create X and y (with noise)
            for l = 1:NrOfX 
                
                [k s l]

                %X = createSparseRandomLowRankInputCommonSupport(dx1,dx2,rank,sparsity(s));
                X = createSparseRandomLowRankInput(dx1,dx2,rank,sparsity(s));
                nrmX = norm(X,'fro');
                X = X*normOfX/nrmX;
                y = A*X(:);
                eps = randn(NrMeas(k),1); eps = (eps/norm(eps))*(normOfX*noise);
                y = y + eps;

                %% Initialize in different ways and recover with ATLAS
                
                [U0,V0] = StartValue(y,A,dx1,dx2,rank);
                [Uatlas,Vatlas] = ATLAS_SIMULATIONVERSION(y,A,alpha,beta,U0,V0,N0,rank,1e-8);
                ErrorMatrixINITtranspose(k,s,l) = norm(X-Uatlas*eye(dx1,dx2)*Vatlas','fro')/norm(X,'fro');

                Z = randn(dx1,dx2);
                Z = Z/norm(Z,'fro');
                [U0,V0] = StartValue(X+100*Z,eye(dx1),dx1,dx2,rank);
                [Uatlas,Vatlas] = ATLAS_SIMULATIONVERSION(y,A,alpha,beta,U0,V0,N0,rank,1e-8);
                ErrorMatrixINITlargeDIST(k,s,l) = norm(X-Uatlas*eye(dx1,dx2)*Vatlas','fro')/norm(X,'fro');
                
                Z = randn(dx1,dx2);
                Z = Z/norm(Z,'fro');
                [U0,V0] = StartValue(X+0.2*Z,eye(dx1),dx1,dx2,rank);
                [Uatlas,Vatlas] = ATLAS_SIMULATIONVERSION(y,A,alpha,beta,U0,V0,N0,rank,1e-8);
                ErrorMatrixINITsmallDIST(k,s,l) = norm(X-Uatlas*eye(dx1,dx2)*Vatlas','fro')/norm(X,'fro');


            end
            
            if (k > 3) && (max(max(sum(ErrorMatrixINITtranspose((k-3):k,s,:) >= SuccessThreshold,3))) == 0) && (max(max(sum(ErrorMatrixINITlargeDIST((k-3):k,s,:) >= SuccessThreshold,3))) == 0) && (max(max(sum(ErrorMatrixINITsmallDIST((k-3):k,s,:) >= SuccessThreshold,3))) == 0)
        
                IS_RECOVERY_ALREADY_SAFE(s) = 1;
            
            end
            
        else
            
            ErrorMatrixINITtranspose(k,s,:) = zeros(NrOfX,1);
            ErrorMatrixINITlargeDIST(k,s,:) = zeros(NrOfX,1);
            ErrorMatrixINITsmallDIST(k,s,:) = zeros(NrOfX,1);
            
        end
            
    end
    
end

%% Data Processing

ProbForSuccRecINITtranspose = sum(ErrorMatrixINITtranspose < SuccessThreshold,3)/NrOfX;
ProbForSuccRecINITlargeDIST = sum(ErrorMatrixINITlargeDIST < SuccessThreshold,3)/NrOfX;
ProbForSuccRecINITsmallDIST = sum(ErrorMatrixINITsmallDIST < SuccessThreshold,3)/NrOfX;

AverageErrorINITtranspose = sum(ErrorMatrixINITtranspose,3)./NrOfX;
AverageErrorINITlargeDIST = sum(ErrorMatrixINITlargeDIST,3)./NrOfX;
AverageErrorINITsmallDIST = sum(ErrorMatrixINITsmallDIST,3)./NrOfX;

save('DATA_Figure7.mat')


        