
load('DATA_Figure3_Rank5.mat')

fontSize = 25;
lineWidth = 3;

f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 

plot(noiseNrm,Error(:,j),'b',noiseNrm,ErrorBound,'--r','LineWidth',lineWidth);

axis([noiseNrm(1) noiseNrm(length(noiseNrm)) 0 1]);
xlabel('Noise to Signal Ratio','FontSize',fontSize);
ylabel('Relative Error','FontSize',fontSize);
set(gca,'FontSize',fontSize)
grid on