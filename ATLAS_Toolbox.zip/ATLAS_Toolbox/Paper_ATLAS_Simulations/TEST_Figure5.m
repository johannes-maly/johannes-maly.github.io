%Simulation scenario to examine influence of norm of X on ATLAS


%% Parameters

abRatio = 1; %=alpha/beta
bRange = 0.5;

ISTAtolerance = [1e-8];

dimX1 = 16;
dimX2 = 100;
sparsity = 0.1;
rank = 1;
measurements = 90;
noiseNrm = 0.0;
N0 = 50;

normX = [0.4:0.2:0.8 1:1:9 10:2:30]; %Frobenius norm of X

Error = zeros(length(bRange),length(ISTAtolerance));

%Measurement Matrix and X
A = randn(measurements,dimX1*dimX2)/(measurements^0.5);
X = createSparseRandomLowRankInputCommonSupport(dimX1,dimX2,rank,sparsity);
X = (X/norm(X,'fro'));

%Constant from Sparsity Control
s = sparsity*dimX2;             ss = s^(1/3);
C21 = (0.5)^(2/3) + 2^(1/3);

%Bound on || X - X_hat ||
ErrorBound = ( ((C21.*ss)^(0.5)) .* ((bRange.^3.*abRatio).^(1/6)) .* ((normX.*SchattenNorm(X,2/3)).^(1/3)) )./normX;

%% Recovery

for k = 1:length(normX)
    
    if mod(k,1) == 0
        k
    end
    
    X = X*normX(k);
    
    %Measurements and Noise 
    y = A*X(:);
    eps = rand(length(y),1);
    eps = eps*noiseNrm*normX(k)/norm(eps);
    y = (y+eps);
    
    %Start Value
    [u0,v0] = StartValue(y,A,dimX1,dimX2,rank);
    
    for j = 1:length(ISTAtolerance)
        
        [U,V] = ATLAS_SIMULATIONVERSION(y,A,abRatio*bRange,bRange,u0,v0,N0,rank,ISTAtolerance(j));
        Error(k,j) = norm(X-U*eye(dimX1,dimX2)*V','fro')/normX(k);
        
    end
    
    X = X/normX(k);
    
end

save('DATA_Figure5.mat')