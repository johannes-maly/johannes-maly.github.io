#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 13:51:42 2020

@author: Johannes Maly
@content: lambda test for covariance estimation
"""

import numpy as np
import numpy.linalg as la
import random as rd
import math
import scipy.linalg as la2
import ToolsCE as TC

#############
## Parameters

p = 5
n = 200
sigma_factor = 1
lamValues = math.sqrt(sigma_factor)*np.arange(0.02,4.02,0.02)

file_name = 'DATA_Figure2.pkl'

number_of_random_sigma = 2

runs = 100

SquaredFrobeniusError = np.zeros((number_of_random_sigma+1,len(lamValues),3))
OperatorNormError = np.zeros((number_of_random_sigma+1,len(lamValues),3))

#######################
## Fix Random Generator

rd.seed(5)

###########
## Run Code

Sigmas = []
Sigmas.append(TC.createSigma(p,'constant_pos',0.2) * sigma_factor)
for i in range(number_of_random_sigma):
    Sigmas.append(TC.createSigma(p,'random',0.2) * (sigma_factor+i))
    
C1_opt = 1

for s in range(len(Sigmas)):
    
    Sigma = Sigmas[s]

    for r in np.arange(runs):
        
        X = TC.createX(p,n,'Gaussian')
        X = la2.sqrtm(Sigma) @ X
        
        tau = 2*np.random.rand(p,n) - 1
        tauHat = 2*np.random.rand(p,n) - 1
        
        SigmaHat = X @ X.T / n
        
        if s == 0 and r == 0:
            error = np.inf 
            for i in range(100):
                SigmaHatAdaptive, lam_Adaptive = TC.ditheredAdaptiveEstimatorFINAL(X, tau, tauHat, psd=True, lam_factor=i/100)
                if la.norm(SigmaHatAdaptive-Sigma,2) < error:
                    error = la.norm(SigmaHatAdaptive-Sigma,2)
                    C1_opt = i/100
        
        SigmaHatAdaptive, lam_Adaptive = TC.ditheredAdaptiveEstimatorFINAL(X, tau, tauHat, psd=True, lam_factor=C1_opt)
        
        for l in np.arange(len(lamValues)):
            
            print('run = ' + str([s, r, l]))
            
            lam = lamValues[l]*la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf)
            
            ## Estimator Computation
            
            SigmaHatDithered = TC.ditheredEstimator(X, tau, tauHat, lam)
            
            ## Error Calculation
            
            OperatorNormError[s,l,0] = OperatorNormError[s,l,0] + la.norm(SigmaHat-Sigma,2)/la.norm(Sigma,2)
            
            OperatorNormError[s,l,1] = OperatorNormError[s,l,1] + la.norm(SigmaHatAdaptive-Sigma,2)/la.norm(Sigma,2)
            
            OperatorNormError[s,l,2] = OperatorNormError[s,l,2] + la.norm(SigmaHatDithered-Sigma,2)/la.norm(Sigma,2)

## Process and save output

SquaredFrobeniusError = SquaredFrobeniusError/runs
OperatorNormError = OperatorNormError/runs

import pickle
# Saving the objects:
with open(file_name, 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([SquaredFrobeniusError,OperatorNormError,lamValues], f)



