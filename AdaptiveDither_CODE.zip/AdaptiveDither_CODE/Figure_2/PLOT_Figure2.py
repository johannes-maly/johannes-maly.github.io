#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 27 14:09:13 2020

@author: johannes
@content: lambda plot for covariance estimation
"""

import pickle
# Getting back the objects:
with open('DATA_Figure2.pkl','rb') as f:  # Python 3: open(..., 'rb')
    [SquaredFrobeniusError,OperatorNormError,lamValues] = pickle.load(f)

import matplotlib.pyplot as plt

plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=12)     # fontsize of the axes title
plt.rc('axes', labelsize=12)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=10)    # fontsize of the tick labels
plt.rc('ytick', labelsize=10)    # fontsize of the tick labels
plt.rc('legend', fontsize=14)    # legend fontsize
plt.rc('figure', titlesize=14)  # fontsize of the figure title

for s in range(OperatorNormError.shape[0]):
    if s == 0:
        col = 'k'; alph = 1
    else:
        col = 'tab:blue'; alph = 1/s
    fig1, ax1 = plt.subplots()
    ax1.plot(lamValues, OperatorNormError[s,:,0],'-',linewidth=2,label=r'$\hat{\Sigma}_n$', color = col, alpha = alph)
    ax1.plot(lamValues, OperatorNormError[s,:,2],'--',linewidth=2,label=r'$\Sigma_n^{dith}$', color = col, alpha = alph)
    ax1.plot(lamValues, OperatorNormError[s,:,1],'-.',linewidth=2,label=r'$\Sigma_n^{adap}$', color = col, alpha = alph)
    ax1.set_xlabel("Lambda",fontweight='bold')
    ax1.set_ylabel(r"Relative approximation Error in $\Vert\cdot\Vert$",fontweight='bold')
    ax1.set_xlim(lamValues[0],lamValues[-1])
    ax1.set_ylim(0,1.5)
    ax1.set_xticks([1,2,3,4])
    ax1.set_xticklabels(['1 x $\Vert \Sigma \Vert_\infty$','2 x $\Vert \Sigma \Vert_\infty$','3 x $\Vert \Sigma \Vert_\infty$','4 x $\Vert \Sigma \Vert_\infty$'])
    ax1.legend()


