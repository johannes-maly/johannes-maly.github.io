#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 10:13:14 2020

@author: johannes
@content: Auxiliary functions to run covariance estimation code
"""

import numpy as np
import numpy.matlib as ml
import numpy.linalg as la
import scipy.linalg as la2
import math


###########################################################################
## Parameter Tuning


def findOptimalLambda(X,Sigma,tau,tauHat,lambdaValues,estimatorType='full',secondStep=False,D=1):
    
    p, n = np.shape(X)
    temp_error = np.inf
    lopt = 0
    
    for l in np.arange(len(lambdaValues)): 
        
            lam = lambdaValues[l]#*la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf)
            
            if estimatorType == 'full':
                
                SigmaHatDithered = ditheredEstimator(X, tau, tauHat, lam)
                
                if secondStep:
                    SigmaHatDithered = la2.sqrtm(D) @ SigmaHatDithered @ la2.sqrtm(D)     
            
                if la.norm(SigmaHatDithered-Sigma,2) < temp_error:
                    
                    temp_error = la.norm(SigmaHatDithered-Sigma,2)
                    lopt = l
                    
            elif estimatorType == 'diag':
                
                SigmaDiag = np.identity(p) * Sigma
                SigmaHatDithered = np.identity(p) * ditheredEstimator(X, tau, tauHat, lam)
            
                if la.norm(SigmaHatDithered-SigmaDiag,2)/la.norm(SigmaDiag,2) < temp_error:
                    
                    temp_error = la.norm(SigmaHatDithered-SigmaDiag,2)/la.norm(SigmaDiag,2)
                    lopt = l
                    
            else:
                
                print('Estimator type is not valid!')
                return 0
            
    return lopt

###########################################################################
## Adaptive Dithered Estimator with decoupled dithers FINAL

def ditheredAdaptiveEstimatorDecoupledFINAL(X,tau,tauHat,psd=True,lam_factor=1):
    
    p, n = np.shape(X)
    
    lam = []
    for k in range(n):
        #lam[k] = sum( X_inf[:(k+1)] ) / (k+1) 
        lam.append(lam_factor * math.log(k+1) * ( np.sum( X[:,:(k+1)]**2, axis=1 ) / (k+1) )**0.5 )
    
    SigmaHatDithered_asym = np.zeros((p,p))
    
    for k in range(n):
        q1 = np.diag(lam[k]) @ np.sign(X[:,k][:,None] + np.diag(lam[k]) @ tau[:,k][:,None])
        q2 = np.diag(lam[k]) @ np.sign(X[:,k][:,None] + np.diag(lam[k]) @ tauHat[:,k][:,None])
        SigmaHatDithered_asym = SigmaHatDithered_asym + q1 @ q2.T
    
    SigmaHatDithered_asym = SigmaHatDithered_asym / n
    SigmaHatDithered = 0.5*SigmaHatDithered_asym + 0.5*SigmaHatDithered_asym.T
    if psd:
        d,U = la.eigh(SigmaHatDithered)
        SigmaHatDithered = U @ np.diag(np.maximum(d,0)) @ U.T
    
    return SigmaHatDithered, lam




###########################################################################
## Adaptive Dithered Estimator FINAL

def ditheredAdaptiveEstimatorFINAL(X,tau,tauHat,psd=True,lam_factor=1):
    
    p, n = np.shape(X)
    
    lam = np.zeros(n)
    X_inf = la.norm(X,np.inf,axis=0)
    for k in range(n):
        #lam[k] = sum( X_inf[:(k+1)] ) / (k+1) 
        lam[k] = lam_factor * math.log(k+1) * ( sum( X_inf[:(k+1)] ) / (k+1) )
    
    Q1 = ml.repmat(lam, p, 1) * np.sign(X + ml.repmat(lam, p, 1) * tau)
    Q2 = ml.repmat(lam, p, 1) * np.sign(X + ml.repmat(lam, p, 1) * tauHat)
    SigmaHatDithered_asym = Q1 @ Q2.T / n
    SigmaHatDithered = 0.5*SigmaHatDithered_asym + 0.5*SigmaHatDithered_asym.T
    if psd:
        d,U = la.eigh(SigmaHatDithered)
        SigmaHatDithered = U @ np.diag(np.maximum(d,0)) @ U.T
    
    return SigmaHatDithered, lam



###########################################################################
## Adaptive Dithered Estimator

def ditheredAdaptiveEstimatorBisectional(X,tau,tauHat,lam_init, NrOfBlocks):
    
    p, n = np.shape(X)
    if n % NrOfBlocks != 0:
        print('Number of blocks has to be divisor of number of samples!')
        return 0
    
    block_size = int(n/(2*NrOfBlocks))
    lam = lam_init
    SigmaHat1 = np.zeros((p,p))
    SigmaHat2 = np.zeros((p,p))
    
    for b in range(NrOfBlocks):
        
        SigmaHat1new = ditheredEstimator(X[:,b*block_size:(b+1)*block_size], tau[:,b*block_size:(b+1)*block_size], tauHat[:,b*block_size:(b+1)*block_size], lam)
        SigmaHat2new = ditheredEstimator(X[:,int(n/2)+b*block_size:int(n/2)+(b+1)*block_size], tau[:,int(n/2)+b*block_size:int(n/2)+(b+1)*block_size], tauHat[:,int(n/2)+b*block_size:int(n/2)+(b+1)*block_size], lam)
        
        if b == 0:
            lam = np.max(np.abs(np.diag(SigmaHat1new)))**(0.5)
            SigmaHat1 = SigmaHat1new
            SigmaHat2 = SigmaHat2new
        #elif b > 0 and la.norm(SigmaHat1new/la.norm(SigmaHat1new) - SigmaHat2new/la.norm(SigmaHat2new)) < la.norm(SigmaHat1/la.norm(SigmaHat1) - SigmaHat2/la.norm(SigmaHat2)):
        #elif b > 0 and la.norm(SigmaHat1new - SigmaHat2new) < la.norm(SigmaHat1 - SigmaHat2):
        elif b > 0 and np.max(np.abs(np.diag(SigmaHat1new) - np.diag(SigmaHat2new))) < np.max(np.abs(np.diag(SigmaHat1) - np.diag(SigmaHat2))):
            lam = np.max(np.abs(np.diag(SigmaHat1new)))**(0.5)
            SigmaHat1 = SigmaHat1new
            SigmaHat2 = SigmaHat2new
            
        
            
    return SigmaHat1



###########################################################################
## Adaptive Dithered Estimator Simple

def ditheredAdaptiveEstimatorSimple(X,tau,tauHat,lam_init,MeasurementSplits):
    
    p, n = np.shape(X)
    lam_new = lam_init
    
    for i in range(len(MeasurementSplits)-1):
    
        SigmaHatDithered = ditheredEstimator(X[:,MeasurementSplits[i]:MeasurementSplits[i+1]], tau[:,MeasurementSplits[i]:MeasurementSplits[i+1]], tauHat[:,MeasurementSplits[i]:MeasurementSplits[i+1]], lam_new)
    
        lam_new = np.max(np.abs(np.diag(SigmaHatDithered)))**(0.5)
    
    
    return SigmaHatDithered



###########################################################################
## Adaptive Dithered TwoStep Estimator

def ditheredAdaptiveEstimatorTwoStep(X,tau,tauHat,lam_init, NumberOfMeasurementsStepI, NrOfBlocks,secondStep='biased'):
    
    p, n = np.shape(X)

    SigmaHatDithered = ditheredAdaptiveEstimator(X[:,:NumberOfMeasurementsStepI], tau[:,:NumberOfMeasurementsStepI], tauHat[:,:NumberOfMeasurementsStepI], lam_init, NrOfBlocks)
        
    D = np.identity(p) * SigmaHatDithered
    
    if secondStep == 'biased':
        SigmaHatSign = np.sign( la2.inv(la2.sqrtm(D)) @ X[:,NumberOfMeasurementsStepI:]) @ np.sign( la2.inv(la2.sqrtm(D)) @ X[:,NumberOfMeasurementsStepI:] ).T / (n-NumberOfMeasurementsStepI)
        SigmaHat = np.sin( (math.pi/2) * SigmaHatSign )
    
    else:
        SigmaHat = ditheredEstimator(la2.inv(la2.sqrtm(D)) @ X[:,NumberOfMeasurementsStepI:], tau[:,NumberOfMeasurementsStepI:], tauHat[:,NumberOfMeasurementsStepI:], 1.5)
    
    SigmaHat = la2.sqrtm(D) @ SigmaHat @ la2.sqrtm(D)  
    
    return SigmaHat
    
    

###########################################################################
## Adaptive Dithered Estimator

def ditheredAdaptiveEstimator(X,tau,tauHat,lam_init, NrOfBlocks):
    
    p, n = np.shape(X)
    if n % NrOfBlocks != 0:
        print('Number of blocks has to be divisor of number of samples!')
        return 0
    
    block_size = int(n/NrOfBlocks)
    adaptiveTau = lam_init * np.ones((p,block_size))
    
    for b in range(NrOfBlocks):
        
        Dithered = np.sign(X[:,b*block_size:(b+1)*block_size]+adaptiveTau * tau[:,b*block_size:(b+1)*block_size]) @ np.sign(X[:,b*block_size:(b+1)*block_size]+adaptiveTau * tauHat[:,b*block_size:(b+1)*block_size]).T
        SigmaHatDithered_asym = (1/block_size) * np.diag(adaptiveTau[:,0]) @ Dithered @ np.diag(adaptiveTau[:,0])
        SigmaHatDithered = 0.5*SigmaHatDithered_asym + 0.5*SigmaHatDithered_asym.T
        d,U = la.eigh(SigmaHatDithered)
        SigmaHatDithered = U @ np.diag(np.maximum(d,0)) @ U.T
        
        adaptiveTau = np.diag(SigmaHatDithered)[:,None]**(0.5)
        adaptiveTau = np.matlib.repmat(adaptiveTau,1,block_size)
    
    return SigmaHatDithered



###########################################################################
## Dithered Estimator

def ditheredEstimator(X,tau,tauHat,lam,psd=True):

    Dithered = np.sign(X+lam*tau) @ np.sign(X+lam*tauHat).T
    SigmaHatDithered_asym = (lam**2/X.shape[1]) * Dithered
    SigmaHatDithered = 0.5*SigmaHatDithered_asym + 0.5*SigmaHatDithered_asym.T
    if psd:
        d,U = la.eigh(SigmaHatDithered)
        SigmaHatDithered = U @ np.diag(np.maximum(d,0)) @ U.T
    
    return SigmaHatDithered


###########################################################################
## Biased Estimator (undithered)

def biasedEstimator(X,maxSigma,psd=True):

    SigmaHatSign = np.sign(X) @ np.sign(X.T) / X.shape[1]
    SigmaHatBiased = np.sin( (math.pi/2) * SigmaHatSign ) * maxSigma
    if psd:
        d,U = la.eigh(SigmaHatBiased)
        SigmaHatBiased = U @ np.diag(np.maximum(d,0)) @ U.T
    
    return SigmaHatBiased


###########################################################################
## Dithered Toeplitz Estimator

def ditheredToeplitzEstimator(X,tau,tauHat,lam):

    SigmaHatDithered = ditheredEstimator(X,tau,tauHat,lam)
    p = SigmaHatDithered.shape[0]
    
    sigma = np.zeros((p,1))
    for i in range(p):
        for j in range(p-i):
            sigma[i] += SigmaHatDithered[j,i+j]
            sigma[i] += SigmaHatDithered[i+j,j]
        sigma[i] /= 2*(p-i)
    
    return la2.toeplitz(sigma)


###########################################################################
## Create Covariance Matrices

def createSigma(dimension,type,CovarianceMagnitude=0.5):
    
    if type == 'identity':
        
        Sigma = np.identity(dimension)
        
    elif type == 'constant_pos':
        
        Sigma = CovarianceMagnitude*np.ones((dimension,dimension)) + (1-CovarianceMagnitude)*np.identity(dimension)
        
    elif type == 'constant':
        
        Sigma = CovarianceMagnitude*np.ones((dimension,dimension)) + (1-CovarianceMagnitude)*np.identity(dimension)
        RandomSigns = np.sign(np.random.normal(0,1,(dimension,dimension)))
        RandomSigns = RandomSigns - np.diag(np.diag(RandomSigns)) + np.identity(dimension)
        for i in np.arange(dimension):
            for j in np.arange(dimension):
                RandomSigns[i,j] = RandomSigns[j,i]
                
        Sigma = np.array(Sigma) * np.array(RandomSigns)
        
        d,V = la.eig(Sigma);
        Sigma = V @ np.diag(np.maximum(d,0)) @ la.inv(V);
        
    elif type == 'decaying_pos':
        
        Sigma = np.zeros((dimension,dimension));
        for k in np.arange(dimension):
            for l in np.arange(dimension):
                Sigma[k,l] = CovarianceMagnitude ** (np.abs(k-l))
        
    elif type == 'decaying':
        
        Sigma = np.zeros((dimension,dimension))
        for k in np.arange(dimension):
            for l in np.arange(dimension):
                Sigma[k,l] = CovarianceMagnitude ** (np.abs(k-l))
        
        RandomSigns = np.sign(np.random.normal(0,1,(dimension,dimension)))
        RandomSigns = RandomSigns - np.diag(np.diag(RandomSigns)) + np.identity(dimension)
        for i in np.arange(dimension):
            for j in np.arange(dimension):
                RandomSigns[i,j] = RandomSigns[j,i]
                
        Sigma = np.array(Sigma) * np.array(RandomSigns)
        
        d,V = la.eig(Sigma);
        Sigma = V @ np.diag(np.maximum(d,0)) @ la.inv(V);
        
        
    else:
        
        A = np.random.normal(0,1,(dimension,dimension))
        A = math.sqrt(1-CovarianceMagnitude) * (np.abs(A) / ml.repmat(la.norm(A,axis=0),dimension,1))
        Sigma = A.transpose() @ A + np.sign(A.transpose() @ A) * CovarianceMagnitude 
    
        
    return Sigma




###########################################################################
## Create Data


def createX(dimension,number_of_samples,type,*args):
    
    if type == 'Gaussian':
        
        X = np.random.normal(0,1,(dimension,number_of_samples))
        
    elif type == 'Log-Normal':
        
        ## params = [mu,sigma]
        if len(args) < 1:
            params = [0,1]     
        else:
            params = args[0]    
        
        Y = np.random.normal(params[0],params[1],(dimension,number_of_samples))
        X = np.exp(Y)
        
        #Y = params[1] * (np.random.normal(0,1,(dimension,number_of_samples)) - params[0])
        #X = ( np.exp(Y) - np.exp(params[0] + 0.5*params[1]**2) ) / ( np.exp(params[0] + 0.5*params[1]**2) * math.sqrt(np.exp(params[1]**2) - 1) )
        
    elif type == 'Pareto':
        
        ## params = [k,x_min]
        if len(args) < 1:
            params = [3,1]    
        else:
            params = args[0:1]
        
        Y = np.random.normal(0,1,(dimension,number_of_samples))
        
        X = ( (1-Y)**(-1/params[0]) ) * params[1] - params[0] * params[0] / (params[0]-1)
        X = X / math.sqrt( params[1]*params[0] / ( (params[0]-2) * (params[0]-1)**2 ) )
            
    elif type == 'Student-t':
        
        ## nu = 3
        
        Y = np.random.normal(0,1,(dimension,number_of_samples))
        
        X = np.zeros((dimension,number_of_samples))
        
        F = lambda z : 0.5 + (1/math.pi) * ( (z/(math.sqrt(3) + z**2/math.sqrt(3))) + math.atan(z/math.sqrt(3)) )
        
        for k in np.arange(dimension):
            for l in np.arange(number_of_samples):
                
                X[k,l] = X[k,l]
                #X(k,l) = fzero(F,0);
        
        ## TODO
    
    return X
