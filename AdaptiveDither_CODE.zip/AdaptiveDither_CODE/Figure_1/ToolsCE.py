#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 10:13:14 2020

@author: Johannes Maly
@content: Auxiliary functions to run covariance estimation code
"""

import numpy as np
import numpy.matlib as ml
import numpy.linalg as la
import scipy.linalg as la2
import math


###########################################################################
## Parameter Tuning


def findOptimalLambda(X,Sigma,tau,tauHat,lambdaValues,estimatorType='full',secondStep=False,D=1):
    
    p, n = np.shape(X)
    temp_error = np.inf
    lopt = 0
    
    for l in np.arange(len(lambdaValues)): 
        
            lam = lambdaValues[l]#*la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf)
            
            if estimatorType == 'full':
                
                SigmaHatDithered = ditheredEstimator(X, tau, tauHat, lam)
                
                if secondStep:
                    SigmaHatDithered = la2.sqrtm(D) @ SigmaHatDithered @ la2.sqrtm(D)     
            
                if la.norm(SigmaHatDithered-Sigma,2) < temp_error:
                    
                    temp_error = la.norm(SigmaHatDithered-Sigma,2)
                    lopt = l
                    
            elif estimatorType == 'diag':
                
                SigmaDiag = np.identity(p) * Sigma
                SigmaHatDithered = np.identity(p) * ditheredEstimator(X, tau, tauHat, lam)
            
                if la.norm(SigmaHatDithered-SigmaDiag,2)/la.norm(SigmaDiag,2) < temp_error:
                    
                    temp_error = la.norm(SigmaHatDithered-SigmaDiag,2)/la.norm(SigmaDiag,2)
                    lopt = l
                    
            else:
                
                print('Estimator type is not valid!')
                return 0
            
    return lopt

###########################################################################
## Adaptive Dithered Estimator FINAL

def ditheredAdaptiveEstimatorFINAL(X,tau,tauHat,psd=True,lam_factor=1):
    
    p, n = np.shape(X)
    
    lam = np.zeros(n)
    X_inf = la.norm(X,np.inf,axis=0)
    for k in range(n):
        #lam[k] = sum( X_inf[:(k+1)] ) / (k+1) 
        lam[k] = lam_factor * math.log(k+1) * ( sum( X_inf[:(k+1)] ) / (k+1) )
    
    Q1 = ml.repmat(lam, p, 1) * np.sign(X + ml.repmat(lam, p, 1) * tau)
    Q2 = ml.repmat(lam, p, 1) * np.sign(X + ml.repmat(lam, p, 1) * tauHat)
    SigmaHatDithered_asym = Q1 @ Q2.T / n
    SigmaHatDithered = 0.5*SigmaHatDithered_asym + 0.5*SigmaHatDithered_asym.T
    if psd:
        d,U = la.eigh(SigmaHatDithered)
        SigmaHatDithered = U @ np.diag(np.maximum(d,0)) @ U.T
    
    return SigmaHatDithered, lam


###########################################################################
## Dithered Estimator

def ditheredEstimator(X,tau,tauHat,lam,psd=True):

    Dithered = np.sign(X+lam*tau) @ np.sign(X+lam*tauHat).T
    SigmaHatDithered_asym = (lam**2/X.shape[1]) * Dithered
    SigmaHatDithered = 0.5*SigmaHatDithered_asym + 0.5*SigmaHatDithered_asym.T
    if psd:
        d,U = la.eigh(SigmaHatDithered)
        SigmaHatDithered = U @ np.diag(np.maximum(d,0)) @ U.T
    
    return SigmaHatDithered



###########################################################################
## Create Covariance Matrices

def createSigma(dimension,type,CovarianceMagnitude=0.5):
    
    if type == 'identity':
        
        Sigma = np.identity(dimension)
        
    elif type == 'constant_pos':
        
        Sigma = CovarianceMagnitude*np.ones((dimension,dimension)) + (1-CovarianceMagnitude)*np.identity(dimension)
        
    elif type == 'constant':
        
        Sigma = CovarianceMagnitude*np.ones((dimension,dimension)) + (1-CovarianceMagnitude)*np.identity(dimension)
        RandomSigns = np.sign(np.random.normal(0,1,(dimension,dimension)))
        RandomSigns = RandomSigns - np.diag(np.diag(RandomSigns)) + np.identity(dimension)
        for i in np.arange(dimension):
            for j in np.arange(dimension):
                RandomSigns[i,j] = RandomSigns[j,i]
                
        Sigma = np.array(Sigma) * np.array(RandomSigns)
        
        d,V = la.eig(Sigma);
        Sigma = V @ np.diag(np.maximum(d,0)) @ la.inv(V);
        
    elif type == 'decaying_pos':
        
        Sigma = np.zeros((dimension,dimension));
        for k in np.arange(dimension):
            for l in np.arange(dimension):
                Sigma[k,l] = CovarianceMagnitude ** (np.abs(k-l))
        
    elif type == 'decaying':
        
        Sigma = np.zeros((dimension,dimension))
        for k in np.arange(dimension):
            for l in np.arange(dimension):
                Sigma[k,l] = CovarianceMagnitude ** (np.abs(k-l))
        
        RandomSigns = np.sign(np.random.normal(0,1,(dimension,dimension)))
        RandomSigns = RandomSigns - np.diag(np.diag(RandomSigns)) + np.identity(dimension)
        for i in np.arange(dimension):
            for j in np.arange(dimension):
                RandomSigns[i,j] = RandomSigns[j,i]
                
        Sigma = np.array(Sigma) * np.array(RandomSigns)
        
        d,V = la.eig(Sigma);
        Sigma = V @ np.diag(np.maximum(d,0)) @ la.inv(V);
        
        
    else:
        
        A = np.random.normal(0,1,(dimension,dimension))
        A = math.sqrt(1-CovarianceMagnitude) * (np.abs(A) / ml.repmat(la.norm(A,axis=0),dimension,1))
        Sigma = A.transpose() @ A + np.sign(A.transpose() @ A) * CovarianceMagnitude 
    
        
    return Sigma




###########################################################################
## Create Data


def createX(dimension,number_of_samples,type,*args):
    
    if type == 'Gaussian':
        
        X = np.random.normal(0,1,(dimension,number_of_samples))
        
    elif type == 'Log-Normal':
        
        ## params = [mu,sigma]
        if len(args) < 1:
            params = [0,1]     
        else:
            params = args[0]    
        
        Y = np.random.normal(params[0],params[1],(dimension,number_of_samples))
        X = np.exp(Y)
        
        #Y = params[1] * (np.random.normal(0,1,(dimension,number_of_samples)) - params[0])
        #X = ( np.exp(Y) - np.exp(params[0] + 0.5*params[1]**2) ) / ( np.exp(params[0] + 0.5*params[1]**2) * math.sqrt(np.exp(params[1]**2) - 1) )
        
    elif type == 'Pareto':
        
        ## params = [k,x_min]
        if len(args) < 1:
            params = [3,1]    
        else:
            params = args[0:1]
        
        Y = np.random.normal(0,1,(dimension,number_of_samples))
        
        X = ( (1-Y)**(-1/params[0]) ) * params[1] - params[0] * params[0] / (params[0]-1)
        X = X / math.sqrt( params[1]*params[0] / ( (params[0]-2) * (params[0]-1)**2 ) )
            
    elif type == 'Student-t':
        
        ## nu = 3
        
        Y = np.random.normal(0,1,(dimension,number_of_samples))
        
        X = np.zeros((dimension,number_of_samples))
        
        F = lambda z : 0.5 + (1/math.pi) * ( (z/(math.sqrt(3) + z**2/math.sqrt(3))) + math.atan(z/math.sqrt(3)) )
        
        for k in np.arange(dimension):
            for l in np.arange(number_of_samples):
                
                X[k,l] = X[k,l]
                #X(k,l) = fzero(F,0);
        
        ## TODO
    
    return X
