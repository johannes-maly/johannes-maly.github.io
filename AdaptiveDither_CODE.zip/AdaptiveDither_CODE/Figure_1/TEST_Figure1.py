#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 10:01:50 2020

@author: Johannes Maly
@content: Simulation file for covariance estimation
"""

import numpy as np
import numpy.linalg as la
import random as rd
import scipy.linalg as la2
import ToolsCE as TC

#############
## Parameters

n = 200
pValues = np.arange(5,31,1)
sigma_factor = 1
lamValues = np.arange(0.02,4.02,0.02)
sigma_type = 'constant_pos' 
X_type = 'Gaussian'
MinCovariances = 0.2 
runs = 100

SquaredFrobeniusError = np.zeros((len(pValues),4))
OperatorNormError = np.zeros((len(pValues),4))

#######################
## Fix Random Generator

rd.seed(2)

###########
## Run Code

C1_opt = 1

for r in np.arange(runs):

    for p in np.arange(len(pValues)):
        
        print('run = ' + str([r, p]))

        Sigma = TC.createSigma(pValues[p],sigma_type,MinCovariances)
        Sigma = Sigma*sigma_factor
        
        X = TC.createX(pValues[p],n,X_type)
        X = la2.sqrtm(Sigma) @ X
        
        tau = 2*np.random.rand(pValues[p],n) - 1
        tauHat = 2*np.random.rand(pValues[p],n) - 1
        
        ## Continue with optimal lambda
        
        lopt = TC.findOptimalLambda(X, Sigma, tau, tauHat, lamValues * la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf))
        lam = lamValues[lopt]*la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf)
        
        ## Estimator Computation
        
        SigmaHat = X @ X.T / n

        SigmaHatDithered = TC.ditheredEstimator(X, tau, tauHat, lam)
        
        if r == 0 and p == 0:
            error = np.inf 
            for i in range(100):
                SigmaHatAdaptive, lam_Adaptive = TC.ditheredAdaptiveEstimatorFINAL(X, tau, tauHat, psd=True, lam_factor=i/100)
                if la.norm(SigmaHatAdaptive-Sigma,2) < error:
                    error = la.norm(SigmaHatAdaptive-Sigma,2)
                    C1_opt = i/100
                    
        SigmaHatAdaptive, lam_Adaptive = TC.ditheredAdaptiveEstimatorFINAL(X, tau, tauHat, psd=True, lam_factor=C1_opt)
        
        print('lambda_opt = ' + str(lam) + '; lambda_adap = ' + str(lam_Adaptive[-1]))
        
        
        ## Error Calculation
        
        SquaredFrobeniusError[p,0] = SquaredFrobeniusError[p,0] + la.norm(SigmaHat-Sigma,'fro')**2
        OperatorNormError[p,0] = OperatorNormError[p,0] + la.norm(SigmaHat-Sigma,2)
        
        SquaredFrobeniusError[p,1] = SquaredFrobeniusError[p,1] + la.norm(SigmaHatDithered-Sigma,'fro')**2
        OperatorNormError[p,1] = OperatorNormError[p,1] + la.norm(SigmaHatDithered-Sigma,2)
        
        SquaredFrobeniusError[p,2] = SquaredFrobeniusError[p,2] + la.norm(SigmaHatAdaptive-Sigma,'fro')**2
        OperatorNormError[p,2] = OperatorNormError[p,2] + la.norm(SigmaHatAdaptive-Sigma,2)
        
        

## Process and save output

SquaredFrobeniusError = SquaredFrobeniusError/runs
OperatorNormError = OperatorNormError/runs

import pickle
# Saving the objects:
with open('DATA_Figure1.pkl', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([SquaredFrobeniusError,OperatorNormError,n,pValues,lam,MinCovariances,runs,sigma_type,X_type], f)

