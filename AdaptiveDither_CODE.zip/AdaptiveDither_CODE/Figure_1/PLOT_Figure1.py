#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 16:35:21 2020

@author: Johannes Maly
@content: Plot file for covariance estimation
"""

import pickle
# Getting back the objects:
with open('DATA_Figure1.pkl','rb') as f:  # Python 3: open(..., 'rb')
    [SquaredFrobeniusError,OperatorNormError,n,pValues,lam,MinCovariances,runs,sigma_type,X_type] = pickle.load(f)


import matplotlib.pyplot as plt

plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=12)     # fontsize of the axes title
plt.rc('axes', labelsize=12)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=10)    # fontsize of the tick labels
plt.rc('ytick', labelsize=10)    # fontsize of the tick labels
plt.rc('legend', fontsize=14)    # legend fontsize
plt.rc('figure', titlesize=14)  # fontsize of the figure title

fig1, ax1 = plt.subplots()
ax1.plot(pValues, OperatorNormError[:,0],linewidth=2,label=r'$\hat{\Sigma}_n$', color = 'k')
ax1.plot(pValues, OperatorNormError[:,1],'--',linewidth=2,label=r'$\Sigma_n^{dith}$', color = 'tab:blue', alpha = 0.5)
ax1.plot(pValues, OperatorNormError[:,2],'-.',linewidth=2,label=r'$\Sigma_n^{adap}$', color = 'tab:blue')
ax1.set_xlabel("Ambient Dimension",fontweight='bold')
ax1.set_ylabel(r"Approximation Error in $\Vert\cdot\Vert$",fontweight='bold')
ax1.set_xlim(pValues[0],pValues[-1])
ax1.legend()