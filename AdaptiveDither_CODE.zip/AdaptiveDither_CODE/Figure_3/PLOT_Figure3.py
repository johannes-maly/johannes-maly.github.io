#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 16:35:21 2020

@author: johannes
@content: Plot file for covariance estimation
"""

import pickle
# Getting back the objects:
with open('DATA_Figure3.pkl','rb') as f:  # Python 3: open(..., 'rb')
    [OperatorNormError,n,pValues,lam,MinCovariances,runs,sigma_type,X_type] = pickle.load(f)


import matplotlib.pyplot as plt

plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=12)     # fontsize of the axes title
plt.rc('axes', labelsize=12)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=10)    # fontsize of the tick labels
plt.rc('ytick', labelsize=10)    # fontsize of the tick labels
plt.rc('legend', fontsize=14)    # legend fontsize
plt.rc('figure', titlesize=14)  # fontsize of the figure title

fig1, ax1 = plt.subplots()
ax1.plot(pValues, OperatorNormError[:,0],linewidth=2,label=r'$\hat\Sigma_n$ with $\mathrm{tr}(\Sigma) = p \Vert \Sigma \Vert_\infty$', color = 'k')
ax1.plot(pValues, OperatorNormError[:,1],linewidth=2,label=r'$\hat\Sigma_n$ with $\mathrm{tr}(\Sigma) \ll p \Vert \Sigma \Vert_\infty$', color = 'tab:blue')
#ax1.plot(pValues, OperatorNormError[:,2],linewidth=2,label=r'$\Sigma_n^{dith}$ with $\Sigma_1$', color = 'k')
#ax1.plot(pValues, OperatorNormError[:,3],linewidth=2,label=r'$\Sigma_n^{dith}$ with $\Sigma_2$', color = 'tab:blue')
ax1.plot(pValues, OperatorNormError[:,4],'--',linewidth=2,label=r'$\Sigma_n^{adap}$ with $\mathrm{tr}(\Sigma) = p \Vert \Sigma \Vert_\infty$', color = 'k')
ax1.plot(pValues, OperatorNormError[:,5],'--',linewidth=2,label=r'$\Sigma_n^{adap}$ with $\mathrm{tr}(\Sigma) \ll p \Vert \Sigma \Vert_\infty$', color = 'tab:blue')
ax1.plot(pValues, OperatorNormError[:,6],'-.',linewidth=2,label=r'$\hat\Sigma_n^{adap}$ with $\mathrm{tr}(\Sigma) = p \Vert \Sigma \Vert_\infty$', color = 'k')
ax1.plot(pValues, OperatorNormError[:,7],'-.',linewidth=2,label=r'$\hat\Sigma_n^{adap}$ with $\mathrm{tr}(\Sigma) \ll p \Vert \Sigma \Vert_\infty$', color = 'tab:blue')
#ax1.set_title("Error")
ax1.set_xlabel("Ambient Dimension",fontweight='bold')
ax1.set_ylabel(r"Approximation Error in $\Vert\cdot\Vert$",fontweight='bold')
ax1.set_xlim(pValues[0],pValues[-1])
ax1.legend()