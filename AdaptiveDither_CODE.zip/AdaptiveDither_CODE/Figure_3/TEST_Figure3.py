#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 10:01:50 2020

@author: johannes
@content: Simulation file for covariance estimation
"""

import numpy as np
import copy
import numpy.linalg as la
import random as rd
import math
import scipy.linalg as la2
import ToolsCE as TC
import cvxpy as cp

#############
## Parameters

n = 200
pValues = np.arange(5,31,1)
sigma_factor = 1
lamValues = np.arange(0.02,4.02,0.02)
sigma_type = 'constant_pos' 
X_type = 'Gaussian'
MinCovariances = 0.2 
runs = 100

OperatorNormError = np.zeros((len(pValues),8))

#######################
## Fix Random Generator

rd.seed(2)

###########
## Run Code

C1_opt = 1
C1_opt_LR = 1
C1_opt_Decoupled = 1
C1_opt_Decoupled_LR = 1

for r in np.arange(runs):

    for p in np.arange(len(pValues)):
        
        print('run = ' + str([r, p]))

        Sigma = TC.createSigma(pValues[p],sigma_type,MinCovariances)
        Sigma = Sigma*sigma_factor
        
        SigmaLR = copy.deepcopy(Sigma)
        Scaling = np.eye(pValues[p])/10
        Scaling[0,0] = 1
        SigmaLR = Scaling @ SigmaLR @ Scaling
        
        X = TC.createX(pValues[p],n,X_type)
        XLR = copy.deepcopy(X)
        
        X = la2.sqrtm(Sigma) @ X
        XLR = la2.sqrtm(SigmaLR) @ XLR
        
        tau = 2*np.random.rand(pValues[p],n) - 1
        tauHat = 2*np.random.rand(pValues[p],n) - 1
        
        ## Continue with optimal lambda
        
        lopt = TC.findOptimalLambda(X, Sigma, tau, tauHat, lamValues * la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf))
        lam = lamValues[lopt]*la.norm(np.ndarray.flatten(Sigma)[:,None],np.inf)
        
        loptLR = TC.findOptimalLambda(XLR, SigmaLR, tau, tauHat, lamValues * la.norm(np.ndarray.flatten(SigmaLR)[:,None],np.inf))
        lamLR = lamValues[loptLR]*la.norm(np.ndarray.flatten(SigmaLR)[:,None],np.inf)
        
        
        ## Estimator Computation
        
        SigmaHat = X @ X.T / n
        
        SigmaHatLR = XLR @ XLR.T / n

        #SigmaHatBiased = TC.biasedEstimator(X, np.amax(Sigma))

        SigmaHatDithered = TC.ditheredEstimator(X, tau, tauHat, lam)
        
        SigmaHatDitheredLR = TC.ditheredEstimator(XLR, tau, tauHat, lamLR)
        
        if r == 0 and p == 0:
            error = np.inf 
            for i in range(100):
                SigmaHatAdaptive, lam_Adaptive = TC.ditheredAdaptiveEstimatorFINAL(X, tau, tauHat, psd=False, lam_factor=i/100)
                if la.norm(SigmaHatAdaptive-Sigma,2) < error:
                    error = la.norm(SigmaHatAdaptive-Sigma,2)
                    C1_opt = i/100
                    
        if r == 0 and p == 0:
            error = np.inf 
            for i in range(100):
                SigmaHatAdaptiveLR, lam_AdaptiveLR = TC.ditheredAdaptiveEstimatorFINAL(XLR, tau, tauHat, psd=False, lam_factor=i/100)
                if la.norm(SigmaHatAdaptiveLR-SigmaLR,2) < error:
                    error = la.norm(SigmaHatAdaptiveLR-SigmaLR,2)
                    C1_opt_LR = i/100
                    
        if r == 0 and p == 0:
            error = np.inf 
            for i in range(100):
                SigmaHatAdaptiveDecoupled, lam_AdaptiveDecoupled = TC.ditheredAdaptiveEstimatorDecoupledFINAL(X, tau, tauHat, psd=False, lam_factor=i/100)
                if la.norm(SigmaHatAdaptiveDecoupled-Sigma,2) < error:
                    error = la.norm(SigmaHatAdaptiveDecoupled-Sigma,2)
                    C1_opt_Decoupled = i/100
                    
        if r == 0 and p == 0:
            error = np.inf 
            for i in range(100):
                SigmaHatAdaptiveDecoupledLR, lam_AdaptiveDecoupledLR = TC.ditheredAdaptiveEstimatorFINAL(XLR, tau, tauHat, psd=False, lam_factor=i/100)
                if la.norm(SigmaHatAdaptiveDecoupledLR-SigmaLR,2) < error:
                    error = la.norm(SigmaHatAdaptiveDecoupledLR-SigmaLR,2)
                    C1_opt_Decoupled_LR = i/100
                    
        SigmaHatAdaptive, lam_Adaptive = TC.ditheredAdaptiveEstimatorFINAL(X, tau, tauHat, psd=False, lam_factor=C1_opt)
        SigmaHatAdaptiveLR, lam_AdaptiveLR = TC.ditheredAdaptiveEstimatorFINAL(XLR, tau, tauHat, psd=False, lam_factor=C1_opt_LR)
        SigmaHatAdaptiveDecoupled, lam_AdaptiveDecoupled = TC.ditheredAdaptiveEstimatorDecoupledFINAL(X, tau, tauHat, psd=False, lam_factor=C1_opt_Decoupled)
        SigmaHatAdaptiveDecoupledLR, lam_AdaptiveDecoupledLR = TC.ditheredAdaptiveEstimatorDecoupledFINAL(XLR, tau, tauHat, psd=False, lam_factor=C1_opt_Decoupled_LR)
                
        
        ## Error Calculation
        
        
        OperatorNormError[p,0] = OperatorNormError[p,0] + la.norm(SigmaHat-Sigma,2)
        
        OperatorNormError[p,1] = OperatorNormError[p,1] + la.norm(SigmaHatLR-SigmaLR,2)
        
        OperatorNormError[p,2] = OperatorNormError[p,2] + la.norm(SigmaHatDithered-Sigma,2)
        
        OperatorNormError[p,3] = OperatorNormError[p,3] + la.norm(SigmaHatDitheredLR-SigmaLR,2)
        
        OperatorNormError[p,4] = OperatorNormError[p,4] + la.norm(SigmaHatAdaptive-Sigma,2)
        
        OperatorNormError[p,5] = OperatorNormError[p,5] + la.norm(SigmaHatAdaptiveLR-SigmaLR,2)
        
        OperatorNormError[p,6] = OperatorNormError[p,6] + la.norm(SigmaHatAdaptiveDecoupled-Sigma,2)
        
        OperatorNormError[p,7] = OperatorNormError[p,7] + la.norm(SigmaHatAdaptiveDecoupledLR-SigmaLR,2)
        
        
        
        
## Process and save output

OperatorNormError = OperatorNormError/runs

import pickle
# Saving the objects:
with open('DATA_Figure3.pkl', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([OperatorNormError,n,pValues,lam,MinCovariances,runs,sigma_type,X_type], f)

#import dill
#dill.dump_session('DATA_OperatorVSFrobenius_VaryingP.pkl')
