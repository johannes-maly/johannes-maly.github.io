% --- plots Results --- 

%% --- variable names ---
% errorMatrix      matrix containing errors (runs x length(mRange)
% mRange           range of number of measurments
% runs             number of runs

% load('ResultsPLUSvsNOPLUS_MNIST_SAMPTA19_scaledbyR');
load('ResultsPLUSvsNOPLUS_MNIST_SAMPTA19_scaledbyR_TwoAlgorithms2.mat');
load('ResultsPLUSvsNOPLUS_MNIST');

%fontSize = 20;
lineWidth = 4;

%% --- computing the average error --- 
%averageError = sum(ErrorMatrix)/size(ErrorMatrix,1);
averageErrorNOPLUS = sum(ErrorMatrixNOPLUS)/size(ErrorMatrixNOPLUS,1);
averageErrorPLUS = sum(ErrorMatrixPLUS)/size(ErrorMatrixPLUS,1);
averageErrorExhaustive=sum(ErrorMatrixExhaustive)/size(ErrorMatrixExhaustive,1);
averageErrorTwoStep=sum(ErrorMatrixTwoStep)/size(ErrorMatrixTwoStep,1);
averageErrorExhaustive_Bernoulli=sum(ErrorMatrixExhaustive_Bernoulli)/size(ErrorMatrixExhaustive_Bernoulli,1);
ErrorMatrixTwoStep_Bernoulli(isnan(ErrorMatrixTwoStep_Bernoulli)) = 1;
averageErrorTwoStep_Bernoulli=sum(ErrorMatrixTwoStep_Bernoulli)/size(ErrorMatrixTwoStep_Bernoulli,1);
%averageErrorTwoStep_Bernoulli=sum(ErrorMatrixTwoStep_Bernoulli,'omitnan')/size(ErrorMatrixTwoStep_Bernoulli,1);


%% --- semi-log plot --- 
f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
semilogy([1:1:length(mRange)],averageErrorNOPLUS,'-','LineWidth',lineWidth)
hold on
%semilogy([1:1:length(mRange)],averageErrorPLUS,'-.','LineWidth',lineWidth)
semilogy([1:1:length(mRange)],averageErrorExhaustive,'--','LineWidth',lineWidth)
semilogy([1:1:length(mRange)],averageErrorExhaustive_Bernoulli,'--','LineWidth',2)
semilogy([1:1:length(mRange)],averageErrorTwoStep,':','LineWidth',lineWidth)
semilogy([1:1:length(mRange)],averageErrorTwoStep_Bernoulli,':','LineWidth',2)
%% --- lable axes --- 
%legend('log averageErrorPLUS','log averageErrorNOPLUS','Location','southeast')
% set size of figure
set(gcf, 'Units', 'pixels');
set(gcf,'Position', [145 91 740 570]);
set(gca, 'Units', 'pixels');
set(gca,'Position', [116.94 92.60 571.95 456.4]);

% set XTicks and position XLabels
set(gca,'XTick',[1:length(mRange)]) 
set(gca,'XTickLabel',mRange)  
set(gca,'xticklabelrotation',45)
xlim([1,length(mRange)])

hxLabel = get(gca,'XLabel');
set(hxLabel, 'Units', 'pixels');
set(hxLabel, 'Position', [287.0003 -60 0]); 

% position YLabels
hyLabel = get(gca,'YLabel'); 
set(hyLabel, 'Units', 'pixels');
set(hyLabel, 'Position', [-80.0000 229.2502 0]); 

% fix bug in matlabfrag 
YTickLabel = get(gca,'YTickLabel');
for k=1:length(YTickLabel)
    YTickLabel{k}=['$',YTickLabel{k},'$'];
end
set(gca,'YTickLabel',YTickLabel)

% set Labels
xl=xlabel('Number of Measurements');set(xl,'Interpreter','latex')
yl=ylabel('Average Error'); set(yl,'Interpreter','latex')
set(gca,'FontSize',8)

grid on

%% --- save & warn --- 
matlabfrag('graphics/SAMPTA19_scaledbyR');
warning('on')
warning(' in .tex noch [ct][ct] durch [rt][rt] ersetzen')

