%Test to compare recovery using []_+ with recovery not using []_+
%
%   mRange          -   Number of measurements
%   runs            -   Recoveries per measurement setting
%   eps             -   Tolerance in fulfilling side conditions
%   R               -   Ball radius as in Paper


%% Parameters

mRange = [10:10:100 200:100:1000 2000:1000:10000];%[5,10,50,100,500,1000,5000,10000];
runs   = 100;
%R      = 1.5;

ErrorMatrixExhaustive = zeros(runs,length(mRange));
ErrorMatrixTwoStep = zeros(runs,length(mRange));
ErrorMatrixExhaustive_Bernoulli = zeros(runs,length(mRange));
ErrorMatrixTwoStep_Bernoulli = zeros(runs,length(mRange));


%% Build GMRA and project onto sphere

[X,gMRA] = getGMRA_SAMPTA19(16,20000,2,0,0,1,50);
D = size(X,1);

%% Determine R

R = max(sqrt(sum(X.^2)));
lambda = 1.2*R;

%% Choose set of random x to be recovered
pos = randperm(size(X,2));
pos = pos(1:runs);
xRuns = X(:,pos);
xRuns = double(xRuns);

%% Iterate through scenarios and recover

%clear all
%load('PLUSvsNOPLUS_MNIST_IntermediateResult.mat');

for m = 1:length(mRange)
    
    mRange(m)
    %Create measurement matrix
    A = randn(mRange(m),D);%/(mRange(m)^.5);
    A_Bernoulli = sign1B(randn(mRange(m),D));
    tau = 2*lambda*rand(mRange(m),1) - lambda;
    
    for r = 1:runs
        
        r
        x = xRuns(:,r);
        
        %Create measurements
        y = sign1B(A*x+tau);
        y_Bernoulli = sign1B(A_Bernoulli*x+tau);
        
        %Recover with SAMPTA19 (All in ONE)
        xhatExhaustive = OMSstepII_SAMPTA19_Exhaustive(A,y,gMRA,lambda,R);
        xhatExhaustive_Bernoulli = OMSstepII_SAMPTA19_Exhaustive(A_Bernoulli,y_Bernoulli,gMRA,lambda,R);
        
        %Recover center
        cNrNOTREE = OMSstepI_SAMPTA19(A,y,gMRA,0,tau);
        cNrNOTREE_Bernoulli = OMSstepI_SAMPTA19(A_Bernoulli,y_Bernoulli,gMRA,0,tau);
        
        %Recover with SAMPTA19 (Two Steps)
        xhatTwoStep = OMSstepII_SAMPTA19(A,y,gMRA,cNrNOTREE,lambda,R);
        xhatTwoStep_Bernoulli = OMSstepII_SAMPTA19(A_Bernoulli,y_Bernoulli,gMRA,cNrNOTREE_Bernoulli,lambda,R);
        
        %Update ErrorMatrix
        ErrorMatrixExhaustive(r,m) = norm(x-xhatExhaustive);
        ErrorMatrixTwoStep(r,m) = norm(x-xhatTwoStep);
        ErrorMatrixExhaustive_Bernoulli(r,m) = norm(x-xhatExhaustive_Bernoulli);
        ErrorMatrixTwoStep_Bernoulli(r,m) = norm(x-xhatTwoStep_Bernoulli);
        
    end
    
%     save('PLUSvsNOPLUS_MNIST_IntermediateResult.mat');
    
end

save('ResultsPLUSvsNOPLUS_Sphere_SAMPTA19_scaledbyR_TwoAlgorithms2.mat')
         
       


