function [ xhat ] = OMSstepII_Sjoerd( A,y,gMRA,copt,lambda,R )
%   Returns xhat as described in OMS
%    
%   A,y                 -   One-bit measurements obtained as y = sign(Ax)
%   gMRA                -   gMRA File
%   copt                -   Number of center determined in step I1
%   lambda              -   Parameter from Sjoerd paper
%   R                   -   Signal set radius

    [m,D] = size(A);
    if nargin < 6
        plusSetting = 1;
    end
    
    Phi = gMRA.ScalBasis(copt);
    Phi = double(Phi{1});
    c = gMRA.Centers(copt);
    c = double(c{1});
    
    %P0 is the projection of 0 onto Pjk'
    P0 = c - Phi'*Phi*c;
    P0normed = P0/norm(P0);
    
    if sign1B(A*c) == y
        
        xhat = c;
        %disp('c is already optimal');
        
    else
        
        xhat = lambda/m*A'*y;
        xhat = Phi'*Phi*xhat;
        xhat = min(norm(xhat), sqrt(4*R^2-norm(c)^2))*xhat/norm(xhat) + c;
        
    end

end

