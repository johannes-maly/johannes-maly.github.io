function [ cNr ] = OMSstepI_Sjoerd( A,y,gMRA,treeStructure,tau,NumberOfCentersConsidered )
%   Returns number of a center which is closest to x in one-bit measurments (Step I
%   of OMS)
%
%   y,A                         -       one-bit measurements obtained as y = sign(Ax)
%   gMRA                        -       GMRA file
%   treeStructure               -       1 if tree structure shall be used
%   numberOfCentersConsidered   -       Number of children considered in
%                                       each step of tree search
%                                       (Default = 15)
    

    %% No Tree Structure

    if treeStructure ~= 1
        
        cNr = 1;
        cell = gMRA.Centers(1);
        cnorm = norm(sign1B(A*cell{1}+tau)-y);

        for k = 1:length(gMRA.Centers)

            cell = gMRA.Centers(k);

            if norm(sign1B(A*cell{1}+tau)-y) < cnorm

                cNr = k;
                cnorm = norm(sign1B(A*cell{1}+tau)-y);

            end

        end
        
    end
    
    %% Tree Structure
    
    if treeStructure == 1
        
        if nargin < 5
            NumberOfCentersConsidered = 15;
        end
        
        cp = gMRA.cp;
        children = [1];
        goodCenters = zeros(NumberOfCentersConsidered,1);
        cnorms = inf*ones(NumberOfCentersConsidered,1);

        while length(children) > 0

            %First init of considered centers
            goodCenters = children(1:min(length(children),NumberOfCentersConsidered));
            if length(goodCenters)<=length(cnorms)
                cnorms = zeros(length(goodCenters),1);
            else
                cnorms = zeros(length(goodCenters),1);
            end

            for k = 1:length(goodCenters)

                cell = gMRA.Centers(children(k));
                cnorms(k) = norm(sign1B(A*cell{1}+tau)-y);

            end

            %Find centers to be considered
            for k = 1:length(children)

                cell = gMRA.Centers(children(k));
                cellnorm = norm(sign1B(A*cell{1}+tau)-y);

                if cellnorm < max(cnorms)

                    [B,I] = max(cnorms);
                    goodCenters(I) = children(k);
                    cnorms(I) = cellnorm;

                end

            end

            children = [];
            for k = 1:length(goodCenters)

                children = [children find(cp==goodCenters(k))];

            end

        end

        [B,I] = min(cnorms);
        length(I);
        cNr = goodCenters(I);
        
    end

end

