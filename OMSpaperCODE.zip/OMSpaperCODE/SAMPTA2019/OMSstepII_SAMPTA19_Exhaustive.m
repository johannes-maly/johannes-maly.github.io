function [ xhat_Final,cNr ] = OMSstepII_Sjoerd_Exhaustive( A,y,gMRA,lambda,R )
%   Returns xhat as described in OMS
%    
%   A,y                 -   One-bit measurements obtained as y = sign(Ax)
%   gMRA                -   gMRA File
%   lambda              -   Parameter from Sjoerd paper
%   R                   -   Signal set radius

    [m,D] = size(A);
    
    cNr = 1;
    
    Phi = gMRA.ScalBasis(1);
    Phi = double(Phi{1});
    c = gMRA.Centers(1);
    c = double(c{1});
    
    xBackprojection = lambda/m*A'*y;
    
    xhat = Phi'*Phi*xBackprojection;
    xhat = min(norm(xhat), sqrt(4*R^2-norm(c)^2))*xhat/norm(xhat) + c;
    
    comp_quantity = norm(xBackprojection - xhat);
    xhat_Final = xhat;

    for k = 1:length(gMRA.Centers)
        
        Phi = gMRA.ScalBasis(k);
        Phi = double(Phi{1});
        c = gMRA.Centers(k);
        c = double(c{1});

        %xBackprojection = lambda/m*A'*y;

        xhat = Phi'*Phi*xBackprojection;
        xhat = min(norm(xhat), sqrt(4*R^2-norm(c)^2))*xhat/norm(xhat) + c;

        if norm(xBackprojection - xhat) < comp_quantity

            cNr = k;
            comp_quantity = norm(xBackprojection - xhat);
            xhat_Final = xhat;

        end

    end

end

