function [ xhat ] = OMSstepII_simple( A,y,gMRA,copt,eps,R,plusSetting )
%   Returns xhat as described in OMS - Simple Version
%    
%   A,y                 -   One-bit measurements obtained as y = sign(Ax)
%   gMRA                -   gMRA File
%   copt                -   Number of center determined in step I
%   eps                 -   Tolerance in fulfilling side conditions
%   R                   -   Ball radius as in Paper
%   plusSetting         -   1 if []_+ shall be considered (Default = 1)

    [m,D] = size(A);
    if nargin < 7
        plusSetting = 1;
    end
    
    
    Phi = gMRA.ScalBasis(copt);
    Phi = double(Phi{1});
    c = gMRA.Centers(copt);
    c = double(c{1});
    
    if sign1B(A*c) == y
        
        xhat = c;
        %disp('c is already optimal');
        
    else
    
        if plusSetting == 1
            
            cvx_begin quiet
                cvx_precision high
                variable w(D)
                minimize( sum(max(-y.*(A*w),zeros(m,1))) )
                subject to

                    (Phi'*Phi-eye(D))*w+(c-Phi'*Phi*c) <= eps;
                    norm(w) <= R;

            cvx_end

            xhat = w;
            
        else
            
            cvx_begin quiet
                cvx_precision high
                variable w(D)
                minimize( sum(-y.*(A*w)) )
                subject to

                    (Phi'*Phi-eye(D))*w+(c-Phi'*Phi*c) <= eps;
                    norm(w) <= R;

            cvx_end

            xhat = w;
            
        end
        
    end

end

