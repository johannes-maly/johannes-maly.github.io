function [ xhat ] = OMSstepII( A,y,gMRA,copt,eps,plusSetting )
%   Returns xhat as described in OMS
%    
%   A,y                 -   One-bit measurements obtained as y = sign(Ax)
%   gMRA                -   gMRA File
%   copt                -   Number of center determined in step I
%   eps                 -   Tolerance in fulfilling side conditions
%   plusSetting         -   1 if []_+ shall be considered (Default = 1)

    [m,D] = size(A);
    if nargin < 6
        plusSetting = 1;
    end
    
    Phi = gMRA.ScalBasis(copt);
    Phi = double(Phi{1});
    c = gMRA.Centers(copt);
    c = double(c{1});
    
    %P0 is the projection of 0 onto Pjk'
    P0 = c - Phi'*Phi*c;
    P0normed = P0/norm(P0);
    
    if sign1B(A*c) == y
        
        xhat = c;
        %disp('c is already optimal');
        
    else
        
        if plusSetting == 1
    
            cvx_begin quiet
                cvx_precision high
                variable w(D)
                minimize( sum(max(-y.*(A*w),zeros(m,1))) )
                subject to

                    norm(w) <= 1;
                    norm((Phi'*Phi-eye(D))*w + (P0normed'*w)*P0normed) <= eps;
                    P0'*((P0normed'*w)*P0normed) >= 0.5*norm(P0)^2;

            cvx_end

            xhat = w;
            
        else
            
            cvx_begin quiet
                cvx_precision high
                variable w(D)
                minimize( sum(-y.*(A*w)) )
                subject to

                    norm(w) <= 1;
                    norm((Phi'*Phi-eye(D))*w + (P0normed'*w)*P0normed) <= eps;
                    P0'*((P0normed'*w)*P0normed) >= 0.5*norm(P0)^2;

            cvx_end

            xhat = w;
            
        end
        
    end

end

