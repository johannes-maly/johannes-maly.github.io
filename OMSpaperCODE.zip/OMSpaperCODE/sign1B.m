function [ X1B ] = sign1B( X )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

    X0 = (X==0);
    X(X0) = 1;
    X1B = sign(X);

end

