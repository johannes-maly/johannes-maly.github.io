Date: May 10, 2018

Author: Sara Krause-Solberg, Johannes Maly (Technical University of Munich, Germany)

This file contains the necessary steps to set up the simulations of the paper "A tractable approach to one-bit compressed sensing on manifolds" (https://arxiv.org/abs/1807.06490). All files are created on and designed for Matlab R2015b.

The following additional software is needed as a basis:

1.) CVX-toolbox for convex programming (see http://cvxr.com/cvx/).

2.) The Geometric Multi-Resolution Analysis (GMRA) kit provided by Mauro Maggioni (see https://mauromaggioni.duckdns.org/#tab_code). This includes parts of the MNIST data set.

After equipping MATLAB with CVX and setting up the GMRA kit one file of the GMRA code has to be exchanged: Replace in the GMRA code GMRA/DiffusionGeometry/Examples/GenerateTrainAndTestData.m by our version (AdditionalGMRAFiles/GenerateTrainAndTestData.m) containing a projection of the data to the sphere necessary in the one-bit setting.

The file AdditionalGMRAFiles/getGMRA.m is a combination of the GMRA code files GMRA/DiffusionGeometry/Examples/SelectDataSetAndOptions.m and GMRA/RunExamples.m and is necessary for running the simulations.

To finally run the simulations execute the file NumericalSimulations/runTests.m which starts all single simulations. The tests can be found in NumericalSimulations/SingleTestFiles. The files to plot the data are in NumericalSimulations/PlotFilesXXXX.

The folder SAMPTA19 contains adapted code fragments used to create numerical simulations for the SAMPTA follow-up paper https://sampta2019.sciencesconf.org/267528/document
 
Have fun and update us on probable errors;) 