%Test to compare recovery using tree structure with recovery checking all
%possible centers
%
%   mRange          -   Number of measurements
%   runs            -   Recoveries per measurement setting
%   eps             -   Tolerance in fulfilling side conditions
%   R               -   Ball radius as in Paper


%% Parameters

mRange = [10:10:100 200:100:1000 2000:1000:10000];%[5,10,50,100,500,1000,5000,10000];
runs   = 100;
eps    = 1e-4;
%R      = 1.5;

ErrorMatrixTREE1STEP = zeros(runs,length(mRange));
ErrorMatrixNOTREE1STEP = zeros(runs,length(mRange));
ErrorMatrixTREE2STEP = zeros(runs,length(mRange));
ErrorMatrixNOTREE2STEP = zeros(runs,length(mRange));

%% Build GMRA and project onto sphere

[X,gMRA] = getGMRA(1,20000,2,0,0,1,50);
D = size(X,1);

%% Choose set of random x to be recovered
pos = randperm(size(X,2));
pos = pos(1:runs);
xRuns = X(:,pos);
xRuns = double(xRuns);

%% Iterate through scenarios and recover

for m = 1:length(mRange)
    
    mRange(m);
    %Create measurement matrix
    A = randn(mRange(m),D)/(mRange(m)^.5);
    
    for r = 1:runs
        
        x = xRuns(:,r);
        
        %Create measurements
        y = sign1B(A*x);
        
        %Recover with tree structure
        cNrTREE = OMSstepI(A,y,gMRA,1,5);
        xhatTREE1STEP = gMRA.Centers(cNrTREE);
        xhatTREE1STEP = double(xhatTREE1STEP{1});
        xhatTREE2STEP = OMSstepII(A,y,gMRA,cNrTREE,eps,0);
        
        %Recover without tree structure
        cNrNOTREE = OMSstepI(A,y,gMRA,0);
        xhatNOTREE1STEP = gMRA.Centers(cNrNOTREE);
        xhatNOTREE1STEP = double(xhatNOTREE1STEP{1});
        xhatNOTREE2STEP = OMSstepII(A,y,gMRA,cNrNOTREE,eps,0);
        
        %Update ErrorMatrix
        ErrorMatrixTREE1STEP(r,m) = norm(x-xhatTREE1STEP);
        ErrorMatrixNOTREE1STEP(r,m) = norm(x-xhatNOTREE1STEP);
        ErrorMatrixTREE2STEP(r,m) = norm(x-xhatTREE2STEP);
        ErrorMatrixNOTREE2STEP(r,m) = norm(x-xhatNOTREE2STEP);
        
    end
    
end

save('./PaperSimulationTestFiles/PlotFilesMNIST/ResultsTREEvsNOTREE_MNIST.mat')
         
       


