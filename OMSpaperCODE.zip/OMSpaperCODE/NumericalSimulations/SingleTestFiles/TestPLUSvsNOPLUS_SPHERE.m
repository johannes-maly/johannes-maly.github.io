%Test to compare recovery using []_+ with recovery not using []_+
%
%   mRange          -   Number of measurements
%   runs            -   Recoveries per measurement setting
%   eps             -   Tolerance in fulfilling side conditions
%   R               -   Ball radius as in Paper


%% Parameters

mRange = [10:10:100 200:100:1000 2000:1000:10000];%[5,10,50,100,500,1000,5000,10000];
runs   = 100;
eps    = 1e-4;
%R      = 1.5;

ErrorMatrixPLUS = zeros(runs,length(mRange));
ErrorMatrixNOPLUS = zeros(runs,length(mRange));

%% Build GMRA and project onto sphere

[X,gMRA] = getGMRA(16,20000,2,0,0,1,50);
D = size(X,1);

%% Choose set of random x to be recovered
pos = randperm(size(X,2));
pos = pos(1:runs);
xRuns = X(:,pos);
xRuns = double(xRuns);

%% Iterate through scenarios and recover

for m = 1:length(mRange)
    
    mRange(m);
    %Create measurement matrix
    A = randn(mRange(m),D)/(mRange(m)^.5);
    
    for r = 1:runs
        
        x = xRuns(:,r);
        
        %Create measurements
        y = sign1B(A*x);
        
        %Recover center
        cNrNOTREE = OMSstepI(A,y,gMRA,0);
        
        %Recover with ReLU
        xhatPLUS = OMSstepII(A,y,gMRA,cNrNOTREE,eps,1);
        
        %Recover without ReLU
        xhatNOPLUS = OMSstepII(A,y,gMRA,cNrNOTREE,eps,0);
        
        %Update ErrorMatrix
        ErrorMatrixPLUS(r,m) = norm(x-xhatPLUS);
        ErrorMatrixNOPLUS(r,m) = norm(x-xhatNOPLUS);
        
    end
    
end

save('./PaperSimulationTestFiles/PlotFilesSPHERE/ResultsPLUSvsNOPLUS_SPHERE.mat')
         
       


