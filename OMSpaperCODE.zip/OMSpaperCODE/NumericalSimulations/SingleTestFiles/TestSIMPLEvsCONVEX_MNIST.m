%Test to compare recovery using []_+ with recovery not using []_+
%
%   mRange          -   Number of measurements
%   runs            -   Recoveries per measurement setting
%   eps             -   Tolerance in fulfilling side conditions
%   R               -   Ball radius as in Paper


%% Parameters

mRange = [10:10:100 200:100:1000 2000:1000:10000];%[5,10,50,100,500,1000,5000,10000];
%mRange = [2000:1000:10000];
runs   = 100;
eps    = 1e-4;
R      = 1.5;

ErrorMatrixSIMPLE = zeros(runs,length(mRange));
ErrorMatrixCONVEX = zeros(runs,length(mRange));

%% Build GMRA and project onto sphere

[X,gMRA] = getGMRA(1,20000,1,0,0,1,10);
D = size(X,1);

%% Choose set of random x to be recovered
pos = randperm(size(X,2));
pos = pos(1:runs);
xRuns = X(:,pos);
xRuns = double(xRuns);

%% Iterate through scenarios and recover

% %ADD m=600:100:1000
% clear all
% load('./PlotFilesMNIST/ResultsSIMPLEvsCONVEX_MNIST_MISSING1000.mat')
% mRange = 600:100:1000;
% EM_SIMPLE = zeros(runs,28);
% EM_CONVEX = zeros(runs,28);
% EM_SIMPLE(:,1:14) = ErrorMatrixSIMPLE(:,1:14); EM_CONVEX(:,1:14) = ErrorMatrixCONVEX(:,1:14); 
% EM_SIMPLE(:,20:28) = ErrorMatrixSIMPLE(:,15:23); EM_CONVEX(:,20:28) = ErrorMatrixCONVEX(:,15:23);
% ErrorMatrixSIMPLE = EM_SIMPLE;
% ErrorMatrixCONVEX = EM_CONVEX;

for m = 1:length(mRange)
    
    mRange(m)
    %Create measurement matrix
    A = randn(mRange(m),D)/(mRange(m)^.5);
    
    for r = 1:runs
        
        %[m,r]
        
        x = xRuns(:,r);
        
        %Create measurements
        y = sign1B(A*x);
        
        %Recover center
        cNrNOTREE = OMSstepI(A,y,gMRA,0);
        
        %Recover with simple OMS but optimal R
        Phi = gMRA.ScalBasis(cNrNOTREE);
        Phi = double(Phi{1});
        c = gMRA.Centers(cNrNOTREE);
        c = double(c{1});
        R = norm(Phi'*Phi*(x-c) + c);
        xhatSIMPLE = OMSstepII_simple(A,y,gMRA,cNrNOTREE,eps,R,0);
        
        %Recover with OMS
        xhatCONVEX = OMSstepII(A,y,gMRA,cNrNOTREE,eps,0);
        
        %Update ErrorMatrix
        ErrorMatrixSIMPLE(r,m) = norm(x-xhatSIMPLE);
        ErrorMatrixCONVEX(r,m) = norm(x-xhatCONVEX);
        
    end
    
end

save('./PlotFilesMNIST/ResultsSIMPLEvsCONVEX_MNIST.mat')
         
       


