%Test to compare influence of different refinement levels of GMRA
%
%   mRange          -   Number of measurements
%   runs            -   Recoveries per measurement setting
%   eps             -   Tolerance in fulfilling side conditions
%   R               -   Ball radius as in Paper


%% Parameters

mRange = [10:10:100 200:100:1000 2000:1000:10000];%[5,10,50,100,500,1000,5000,10000];
jRange = 3:10;
runs   = 100;
eps    = 1e-4;
%R      = 1.5;

ErrorMatrixJRANGE = zeros(runs,length(mRange),length(jRange));

%% Iterate over refinement levels

% %for intermediate break (CHANGE j=... accordingly!!!)
% clear all
% load('JRANGE_MNIST_INTERMEDIATE.mat')

for j = 1:length(jRange)

%% Build GMRA and project onto sphere

[X,gMRA] = getGMRA(1,20000,2,0,0,1,50,jRange(j));
D = size(X,1);

%% Choose set of random x to be recovered
pos = randperm(size(X,2));
pos = pos(1:runs);
xRuns = X(:,pos);
xRuns = double(xRuns);

%% Iterate through scenarios and recover

for m = 1:length(mRange)
    
    [j,mRange(m)]
    %Create measurement matrix
    A = randn(mRange(m),D)/(mRange(m)^.5);
    
    for r = 1:runs
        
        x = xRuns(:,r);
        
        %Create measurements
        y = sign1B(A*x);
        
        %Recover center
        cNrNOTREE = OMSstepI(A,y,gMRA,0);
        
        %Recover x
        xhat = OMSstepII(A,y,gMRA,cNrNOTREE,eps,0);
        
        %Update ErrorMatrix
        ErrorMatrixJRANGE(r,m,j) = norm(x-xhat);
        
    end
    
end

%save('JRANGE_MNIST_INTERMEDIATE.mat')

end

save('./PlotFilesMNIST/ResultsJRANGE_MNIST.mat')
         
       


