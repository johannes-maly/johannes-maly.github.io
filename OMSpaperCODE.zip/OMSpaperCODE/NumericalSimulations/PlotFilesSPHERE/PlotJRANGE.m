% --- plots Results --- 

%% --- variable names ---
% errorMatrix      matrix containing errors (runs x length(mRange)
% mRange           range of number of measurments
% runs             number of runs

load('ResultsJRANGE_SPHERE');

fontSize = 8;

%% --- computing the average error --- 
averageErrorJRANGE = sum(ErrorMatrixJRANGE)/size(ErrorMatrixJRANGE,1);

%% --- semi-log plot --- 
f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
image([1:1:length(jRange)], [1:1:length(mRange)], squeeze(log10((averageErrorJRANGE))), 'CDataMapping', 'scaled')

%% --- lable axes --- 
cb=colorbar;
legend('log averageErrorJRANGE','Location','southeast')
set(cb,'FontSize',8)

% set size of figure
set(gcf, 'Units', 'pixels');
set(gcf,'Position', [145 91 780 570]);
set(gca, 'Units', 'pixels');
set(gca,'Position', [116.94 92.60 571.95 456.4]);

% set XTicks and position XLabels
set(gca,'XTick',[1:length(jRange)]) 
ij=ismember(jRange,[5 10 15 20 25]);
Lj=ij.*jRange;
XTickLabel = get(gca,'XTickLabel');
for k=1:length(XTickLabel)
    if Lj(k)==0
    XTickLabel{k}=' ';
     else
         XTickLabel{k}=[jRange(k)];
    end
end
set(gca,'XTickLabel',XTickLabel) 
%set(gca,'xticklabelrotation',45)

hxLabel = get(gca,'XLabel');
set(hxLabel, 'Units', 'pixels');
set(hxLabel, 'Position', [287.0003 -60 0]); 

% position YLabels
hyLabel = get(gca,'YLabel'); 
set(hyLabel, 'Units', 'pixels');
set(hyLabel, 'Position', [-80.0000 229.2502 0]); 

set(gca,'YTick',[1:length(mRange)]) 
im=ismember(mRange,[10 50 100 500 1000 5000 10000]);
L=im.*mRange;
YTickLabel = get(gca,'YTickLabel');
for k=1:length(YTickLabel)
    if L(k)==0
    YTickLabel{k}=' ';
     else
         YTickLabel{k}=[mRange(k)];
    end
end
set(gca,'YTickLabel',YTickLabel) 
 
xlabel('Refinement Level')
ylabel('Number of Measurements')
set(gca,'FontSize',fontSize)

% cb = colorbar('vert');
% zlab = get(cb,'ylabel');
% CB=10.^zlab;
% set(zlab,'String','dd'); 

%% --- save --- 
warning('on')
matlabfrag('graphics/JRANGE');




