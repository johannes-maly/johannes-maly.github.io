% --- plots Results --- 

%% --- variable names ---
% errorMatrix      matrix containing errors (runs x length(mRange)
% mRange           range of number of measurments
% runs             number of runs

load('ResultsTREEvsNOTREE_SPHEREnoPlus');

%fontSize = 25;
lineWidth = 3;

%% --- computing the average error --- 
averageErrorTREE1STEP = sum(ErrorMatrixTREE1STEP)/size(ErrorMatrixTREE1STEP,1);
averageErrorNOTREE1STEP = sum(ErrorMatrixNOTREE1STEP)/size(ErrorMatrixNOTREE1STEP,1);
averageErrorTREE2STEP = sum(ErrorMatrixTREE2STEP)/size(ErrorMatrixTREE2STEP,1);
averageErrorNOTREE2STEP = sum(ErrorMatrixNOTREE2STEP)/size(ErrorMatrixNOTREE2STEP,1);

%% --- semi-log plot --- 
f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
semilogy([1:1:length(mRange)],averageErrorTREE1STEP,'--','LineWidth',lineWidth)
hold on
semilogy([1:1:length(mRange)],averageErrorNOTREE1STEP,'-','LineWidth',lineWidth)
semilogy([1:1:length(mRange)],averageErrorTREE2STEP,'-.','LineWidth',lineWidth)
semilogy([1:1:length(mRange)],averageErrorNOTREE2STEP,'-x','LineWidth',lineWidth)

%% --- lable axes --- 
%legend('log averageErrorTREE','log averageErrorNOTREE','Location','southeast')
% set size of figure
set(gcf, 'Units', 'pixels');
set(gcf,'Position', [145 91 740 570]);
set(gca, 'Units', 'pixels');
set(gca,'Position', [116.94 92.60 571.95 456.4]);

% set XTicks and position XLabels
set(gca,'XTick',[1:length(mRange)]) 
set(gca,'XTickLabel',mRange)  
set(gca,'xticklabelrotation',45)
xlim([1,length(mRange)])

hxLabel = get(gca,'XLabel');
set(hxLabel, 'Units', 'pixels');
set(hxLabel, 'Position', [287.0003 -60 0]); 

% position YLabels
hyLabel = get(gca,'YLabel'); 
set(hyLabel, 'Units', 'pixels');
set(hyLabel, 'Position', [-80.0000 229.2502 0]); 

% fix bug in matlabfrag 
YTickLabel = get(gca,'YTickLabel');
for k=1:length(YTickLabel)
    YTickLabel{k}=['$',YTickLabel{k},'$'];
end
set(gca,'YTickLabel',YTickLabel)

% set Labels
xl=xlabel('Number of Measurements');set(xl,'Interpreter','latex')
yl=ylabel('Average Error'); set(yl,'Interpreter','latex')
set(gca,'FontSize',8)

grid on

%% --- save & warn --- 
matlabfrag('graphics/TREEvsNOTREE');
warning('on')
warning('in .tex noch [ct][ct] durch [rt][rt] ersetzen')
