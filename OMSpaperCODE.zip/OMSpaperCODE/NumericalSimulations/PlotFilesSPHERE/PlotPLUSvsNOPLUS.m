% --- plots Results --- 

%% --- variable names ---
% errorMatrix      matrix containing errors (runs x length(mRange)
% mRange           range of number of measurments
% runs             number of runs

load('ResultsPLUSvsNOPLUS_SPHERE');

%fontSize = 20;
lineWidth = 3;

%% --- computing the average error --- 
averageErrorPLUS = sum(ErrorMatrixPLUS)/size(ErrorMatrixPLUS,1);
averageErrorNOPLUS = sum(ErrorMatrixNOPLUS)/size(ErrorMatrixNOPLUS,1);

%% --- semi-log plot --- 
f = figure;
set(f, 'Units', 'normalized', 'Position', [0.1, 0.1, 0.5, 0.6]); 
semilogy([1:1:length(mRange)],averageErrorNOPLUS,'--','LineWidth',lineWidth)
hold on
semilogy([1:1:length(mRange)],averageErrorPLUS,'-','LineWidth',lineWidth)

%% --- lable axes --- 
%legend('log averageErrorPLUS','log averageErrorNOPLUS','Location','southeast')
% set size of figure
set(gcf, 'Units', 'pixels');
set(gcf,'Position', [145 91 740 570]);
set(gca, 'Units', 'pixels');
set(gca,'Position', [116.94 92.60 571.95 456.4]);

% set XTicks and position XLabels
set(gca,'XTick',[1:length(mRange)]) 
set(gca,'XTickLabel',mRange)  
set(gca,'xticklabelrotation',45)
xlim([1,length(mRange)])

hxLabel = get(gca,'XLabel');
set(hxLabel, 'Units', 'pixels');
set(hxLabel, 'Position', [287.0003 -60 0]); 

% position YLabels
hyLabel = get(gca,'YLabel'); 
set(hyLabel, 'Units', 'pixels');
set(hyLabel, 'Position', [-80.0000 229.2502 0]); 

% fix bug in matlabfrag 
YTickLabel = get(gca,'YTickLabel');
for k=1:length(YTickLabel)
    YTickLabel{k}=['$',YTickLabel{k},'$'];
end
set(gca,'YTickLabel',YTickLabel)

% set Labels
xl=xlabel('Number of Measurements');set(xl,'Interpreter','latex')
yl=ylabel('Average Error'); set(yl,'Interpreter','latex')
set(gca,'FontSize',8)

grid on

%% --- save & warn --- 
matlabfrag('graphics/PLUSvsNOPLUS');
warning('on')
warning(' in .tex noch [ct][ct] durch [rt][rt] ersetzen')

