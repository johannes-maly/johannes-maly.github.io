% Run all simulations contained in the paper

%% SIMPLE VS CONVEX

clear all

display('TestSIMPLEvsCONVEX_MNIST: Started')
run('SingleTestFiles/TestSIMPLEvsCONVEX_MNIST.m')
display('TestSIMPLEvsCONVEX_MNIST: Completed')

clear all

display('TestSIMPLEvsCONVEX_SPHERE: Started')
run('SingleTestFiles/TestSIMPLEvsCONVEX_SPHERE.m')
display('TestSIMPLEvsCONVEX_SPHERE: Completed')

%% PLUS VS NO_PLUS

clear all

display('TestPLUSvsNOPLUS_MNIST: Started')
run('SingleTestFiles/TestPLUSvsNOPLUS_MNIST.m')
display('TestPLUSvsNOPLUS_MNIST: Completed')

clear all

display('TestPLUSvsNOPLUS_SPHERE: Started')
run('SingleTestFiles/TestPLUSvsNOPLUS_SPHERE.m')
display('TestPLUSvsNOPLUS_SPHERE: Completed')

%% TREE VS NO_TREE / ONE_STEP VS TWO_STEP

clear all

display('TestTREEvsNOTREE_MNIST: Started')
run('SingleTestFiles/TestTREEvsNOTREE_MNIST.m')
display('TestTREEvsNOTREE_MNIST: Completed')

clear all

display('TestTREEvsNOTREE_SPHERE: Started')
run('SingleTestFiles/TestTREEvsNOTREE_SPHERE.m')
display('TestTREEvsNOTREE_SPHERE: Completed')

%% J_RANGE

clear all

display('TestJRANGE_MNIST: Started')
run('SingleTestFiles/TestJRANGE_MNIST.m')
display('TestJRANGE_MNIST: Completed')

clear all

display('TestJRANGE_SPHERE: Started')
run('SingleTestFiles/TestJRANGE_SPHERE.m')
display('TestJRANGE_SPHERE: Completed')
