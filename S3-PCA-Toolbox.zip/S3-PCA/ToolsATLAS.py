#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 08:54:14 2020

@author: johannes
@content: Auxiliary functions for ATLAS code
"""

import numpy as np
import math
import numpy.linalg as la
import scipy.linalg as la2


############################################################################
### Create initialization

def init(A,y,U,V,perturbation=0,init_type='perfect'):
    
    n1, rank = np.shape(U)
    n2 = np.shape(V)[0]
    
    if init_type == 'perfect':
        
        return U,V
    
    if init_type == 'perturbed':
        
        pert_U = np.random.rand(n1,rank)
        pert_U = perturbation * pert_U * la.norm(U,'fro') / la.norm(pert_U,'fro')
        pert_V = np.random.rand(n2,rank)
        pert_V = perturbation * pert_V * la.norm(V,'fro') / la.norm(pert_V,'fro')
        
        return U+pert_U, V+pert_V
    
    if init_type == 'spectral':
        
        U0, s, V0 = la.svd(np.reshape(A.T @ y,(n1,n2)))
        U0, V0 = U0[:,:rank],V0[:,:rank]
        
        return U0, V0


############################################################################
### ATLAS PALM-Version

def ATLAS_PALM( y,A,alpha,beta,nu,U0,V0,N_iter,output=False ):
    """   ATLAS implementation for both sided sparse singular vectors
    
            y               -       Vector of measurements obtained as A*X(:)
            A               -       Measurement matrix of dimension m x (n1*n2)
            alpha,beta      -       Parameters of ATLAS
            U0,V0           -       Initialization
            N_iter          -       Number of iterations
            
    """

    [n1,rank] = np.shape(U0)
    n2 = np.shape(V0)[0]
    m = len(y)
    
    U = U0
    V = V0

    ## Iterating the Proximal-Descent steps
    for iter in np.arange(N_iter):
        
        if output == True and iter%100 == 0:
            print('\r','Iteration: '+str(iter)+' of '+str(N_iter),end='')
        
        ## Descent step + Proximal mapping U
        UV = U @ V.T
        GDtemp = A @ np.ndarray.flatten(UV)[:,None] - y
        GDtemp = np.reshape(A.T @ GDtemp,(n1,n2)) @ V
        GDu = np.ndarray.flatten(U)[:,None] - nu * np.ndarray.flatten(GDtemp)[:,None]
        TempU = EN_TO(GDu,alpha[0],alpha[1])
        U = np.reshape(TempU,(n1,rank))
        
        ## Descent step + Proximal mapping V
        UV = U @ V.T
        GDtemp = A @ np.ndarray.flatten(UV)[:,None] - y
        GDtemp = np.reshape(A.T @ GDtemp,(n1,n2)).T @ U
        GDv = np.ndarray.flatten(V)[:,None] - nu * np.ndarray.flatten(GDtemp)[:,None]
        TempV = EN_TO(GDv,beta[0],beta[1])
        V = np.reshape(TempV,(n2,rank))
        
    
    return U,V


############################################################################
### ATLAS AM-Version

def ATLAS_AM( y,A,alpha,beta,U0,V0,N_iter,EnetTol,perturbation,output=False ):
    """   ATLAS implementation for both sided sparse singular vectors
    
            y               -       Vector of measurements obtained as A*X(:)
            A               -       Measurement matrix of dimension m x (n1*n2)
            alpha,beta      -       Parameters of ATLAS
            U0,V0           -       Initialization
            N_iter          -       Number of iterations
            EnetTol         -       Tolerance of ElasticNet as LASSO solver (Default: 1e-8)
            Perturbation    -       Norm of random perturbation added in each step
            
    """

    [n1,rank] = np.shape(U0)
    n2 = np.shape(V0)[0]
    m = len(y)
    
    U = np.zeros((n1,rank,N_iter+1))
    V = np.zeros((n2,rank,N_iter+1))
    U[:,:,0] = U0
    V[:,:,0] = V0
    
    Av = np.zeros((m,n1*rank));           ## Av * vec(U) = A * vec(UV')
    Au = np.zeros((m,n2*rank));           ## Au * vec(V) = A * vec(UV')
    
    ## Iterating the Alternating Minimization
    for iter in np.arange(N_iter):
        
        if output == True:
            print('\r','Iteration: '+str(iter)+' of '+str(N_iter),end='')
        
        ## Create Av
        for l in np.arange(m):
            
            TempAv = np.reshape(A[l,:],(n1,n2)) @ V[:,:,iter]
            Av[l,:] = np.squeeze(np.ndarray.flatten(TempAv))
        
        ## Run Elastic Net for V fixed
        normAv = la.norm(Av)
        if normAv > 0:
            TempU = EN_TA(y/normAv,Av/normAv,alpha[0]/(normAv**2),alpha[1]/(normAv**2),1e6,EnetTol)
        else:
            TempU = np.zeros(n1*rank)
        U[:,:,iter+1] = TempU.reshape(n1,rank)
            
        etaU = np.random.normal(0,1,(n1,rank))
        etaU = perturbation * la.norm(U[:,:,iter+1],'fro') * etaU / la.norm(etaU,'fro')
        U[:,:,iter+1] = U[:,:,iter+1] + etaU
        
        ## Create Au
        for l in np.arange(m):
            
            TempAu = np.reshape(A[l,:],(n1,n2)).T @ U[:,:,iter+1]
            Au[l,:] = np.squeeze(np.ndarray.flatten(TempAu))
        
        ## Run Elastic Net for U fixed
        normAu = la.norm(Au)
        if normAu > 0:
            TempV = EN_TA(y/normAu,Au/normAu,beta[0]/(normAu**2),beta[1]/(normAu**2),1e6,EnetTol)
        else:
            TempV = np.zeros(n2*rank)
        V[:,:,iter+1] = TempV.reshape(n2,rank)
            
        etaV = np.random.normal(0,1,(n2,rank))
        etaV = perturbation * la.norm(V[:,:,iter+1],'fro') * etaV / la.norm(etaV,'fro')
        V[:,:,iter+1] = V[:,:,iter+1] + etaV
            
    
    return U[:,:,-1], V[:,:,-1]


############################################################################
### Elastic Net Thresholding Operator

def EN_TO(x,alpha,beta):
    """ Proximal mapping for elastic net, i.e.,
        
        y = argmin_z |z - x|_2^2 + alpha |z|_2^2 + beta |z|_1
        
    """

    #y = np.sign(x) * np.maximum( np.abs(x) - (beta/2), 0 )/(1+alpha)
    y = np.maximum( np.abs(x) - (beta/2), 0 ) * ( x / np.maximum(np.abs(x),np.finfo(float).eps) ) / (1+alpha)
    
    return y

############################################################################
### Elastic Net Thresholding Algorithm


def EN_TA(y,A,alpha,beta,N_iter,Tolerance,output=False):
    """ Proximal Gradient Descent for Elastic Net

        |Ax - y|_2^2 + alpha*|x|_2^2 + beta*|x|_1
    """
    
    A = np.squeeze(A)
    x = np.zeros((np.shape(A)[1],1))
    
    for iter in np.arange(N_iter):
        
        if output==True:# and iter%100 == 0:
            print('\r','Iteration: '+str(iter)+' of '+str(N_iter),end='')
        
        grad = np.array(2*A.conj().T @ ( A @ x - y))
        xNew = EN_TO( x - grad ,alpha,beta )
        
        if la.norm(xNew - x) < Tolerance:
            
            break
        
        x = xNew
    
    return x


############################################################################
### Create Matrix Input

def createInput(n1,n2,rank,s1,s2,sparsity_type,orthogonality_type,support_type):
    """Create sparse and low-rank signals

      - sparsity_type:            'sparse' or 'l1'
      - orthogonality_type:       'orthogonal' or 'arbitrary'
      - support_type:             'joint' or 'arbitrary'
      - singular_values:          [sigma_1, ..., sigma_rank]
      
    """
    
    U = np.zeros((n1,rank)) 
    V = np.zeros((n2,rank)) 
    
    if sparsity_type == 'l1':
        
        if orthogonality_type != 'arbitrary' or support_type != 'arbitrary':
            raise ValueError
                
        from scipy.sparse import random
        structure = random(n1,rank,rank*s1/(rank*n1)).todense()
        structure = np.sign(structure)
        U = np.array(np.random.normal(0,1,(n1,rank))) * np.array(structure)
        U = math.sqrt(rank) * U / np.linalg.norm(U,'fro');
        etaU = np.array(np.random.normal(0,1,(n1,rank)));
        U = U + math.sqrt(rank) * 0.1*etaU/np.linalg.norm(etaU,'fro');
        
        structure = random(n2,rank,rank*s2/(rank*n2)).todense()
        structure = np.sign(structure)
        V = np.array(np.random.normal(0,1,(n2,rank))) * np.array(structure)
        V = math.sqrt(rank) * V / np.linalg.norm(V,'fro');
        etaV = np.random.normal(0,1,(n2,rank));
        V = V + math.sqrt(rank) * 0.1*etaV/np.linalg.norm(etaV,'fro');
        
    else:
        
        if orthogonality_type == 'arbitrary':
            
            if support_type == 'joint':
                
                U_reduced = np.array(np.random.normal(0,1,(s1,rank)));
                U_reduced = math.sqrt(rank) * U_reduced / np.linalg.norm(U_reduced,'fro');
                U[0:U_reduced.shape[0],:] = U_reduced;
                U = np.random.permutation(U);
                
                V_reduced = np.array(np.random.normal(0,1,(s2,rank)));
                V_reduced = math.sqrt(rank) * V_reduced / np.linalg.norm(V_reduced,'fro');
                V[0:V_reduced.shape[0],:] = V_reduced;
                V = np.random.permutation(V);
                
            else:
                
                from scipy.sparse import random
                U = np.array(random(n1,rank,rank*s1/(rank*n1),data_rvs=np.random.randn).todense())
                U = math.sqrt(rank) * U / np.linalg.norm(U,'fro')
                
                V = np.array(random(n2,rank,rank*s2/(rank*n2),data_rvs=np.random.randn).todense())
                V = math.sqrt(rank) * V / np.linalg.norm(V,'fro')
                
        else:
            
            if support_type == 'joint':
                
                Temp = np.array(np.random.normal(0,1,(s1,s2)))
                U_temp, S_temp, V_temp = np.linalg.svd(Temp)
                U[:U_temp.shape[0],:rank] = U_temp[:,:rank]
                U = np.random.permutation(U)
                U = np.random.permutation(U.T).T
                
                V_temp = np.transpose(V_temp)
                V[:V_temp.shape[0],:rank] = V_temp[:,:rank]
                V = np.random.permutation(V)
                V = np.random.permutation(V.T).T
                
            else:
                
                suppUnionU = np.zeros(n1)
                
                for k in np.arange(rank):
                    
                    from scipy.sparse import random
                    strucU = random(n1,1,rank*s1/(rank*n1)).todense()
                    strucU = np.squeeze(np.array(np.sign(strucU)))
                    U[:,k] = np.squeeze(np.random.normal(0,1,(n1,1))) * strucU
                    comSupp = np.squeeze(np.minimum(suppUnionU,strucU))
                    
                    if k > 0 and np.count_nonzero(comSupp) > 0:
                        
                        if np.count_nonzero(comSupp) == 1:
                            
                            U[np.nonzero(comSupp),k] = 0
                            
                        elif k == 1:
                            
                            Uorth = U[np.nonzero(comSupp),0]
                            Uorth = Uorth / la.norm(Uorth)
                            U[np.nonzero(comSupp),k] = U[np.nonzero(comSupp),k] - Uorth @ Uorth.T @ U[np.nonzero(comSupp),k]
                            
                        else:
                            
                            Uorth = la2.orth(np.squeeze(U[np.nonzero(comSupp),0:k]))
                            U[np.nonzero(comSupp),k] = np.squeeze(U[np.nonzero(comSupp),k].T - Uorth @ Uorth.T @ U[np.nonzero(comSupp),k].T)
                    
                    suppUnionU = np.squeeze(np.maximum(suppUnionU,strucU))
                    U[:,k] = U[:,k] / la.norm(U[:,k])
                        
                    
                suppUnionV = np.zeros(n2)
                
                for k in np.arange(rank):
                    
                    from scipy.sparse import random
                    strucV = random(n2,1,rank*s2/(rank*n2)).todense()
                    strucV = np.squeeze(np.array(np.sign(strucV)))
                    V[:,k] = np.squeeze(np.random.normal(0,1,(n2,1))) * strucV
                    comSupp = np.squeeze(np.minimum(suppUnionV,strucV))
                    
                    if k > 0 and np.count_nonzero(comSupp) > 0:
                        
                        if np.count_nonzero(comSupp) == 1:
                            
                            V[np.nonzero(comSupp),k] = 0
                            
                        elif k == 1:
                            
                            Vorth = V[np.nonzero(comSupp),0]
                            Vorth = Vorth / la.norm(Vorth)
                            V[np.nonzero(comSupp),k] = V[np.nonzero(comSupp),k] - Vorth @ Vorth.T @ V[np.nonzero(comSupp),k]
                            
                        else:
                            
                            Vorth = la2.orth(np.squeeze(V[np.nonzero(comSupp),0:k]))
                            V[np.nonzero(comSupp),k] = np.squeeze(V[np.nonzero(comSupp),k].T - Vorth @ Vorth.T @ V[np.nonzero(comSupp),k].T)
                    
                    suppUnionV = np.squeeze(np.maximum(suppUnionV,strucV))
                    V[:,k] = V[:,k] / la.norm(V[:,k])
                
        
    
    return U,V
