@author: Johannes Maly

@content: Python code to replicate the numerical experiments in „Robust Sensing of Low-Rank Matrices with Non-Orthogonal Sparse Decomposition“, arXiv preprint http://arxiv.org/abs/2103.05523

@HowTo: - running files of the form „TEST_XXX.py“ outputs „DATA_XXX.pkl“

	- running files of the form „PLOT_XXX.py“ plots the data in „DATA_XXX.pkl“

	- files of the form „ToolsXXX.py“ contain auxiliary functions