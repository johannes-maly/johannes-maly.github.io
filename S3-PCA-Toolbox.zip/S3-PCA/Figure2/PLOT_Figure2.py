#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb  3 17:24:39 2021

@author: johannes
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 18 14:33:17 2020

@author: johannes
"""
import matplotlib.pyplot as plt

"""
plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=14)     # fontsize of the axes title
plt.rc('axes', labelsize=14)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=10)    # fontsize of the tick labels
plt.rc('ytick', labelsize=10)    # fontsize of the tick labels
plt.rc('legend', fontsize=14)    # legend fontsize
plt.rc('figure', titlesize=14)  # fontsize of the figure title
"""

## Load Data from DATA_Figure2.mat

import pickle
# Loading the objects:
with open('DATA_Figure2.pkl', 'rb') as f:  # Python 3: open(..., 'wb')
#with open('DATA_Figure2_FINALII.pkl', 'rb') as f:  # Python 3: open(..., 'wb')
    #[mu_PALM,Sparsity_PALM,Sparsity_PALM2,EffSparsity_PALM,EffSparsity_PALM2,Error_PALM,Error_PALM2] = pickle.load(f)
    [ProbForSuccRecSPF,ProbForSuccRecATLAS,AverageErrorSPF,AverageErrorATLAS] = pickle.load(f)

## Figure 1 - SPF, Best Approximation

plt.figure()
plt.xlabel('$s/n_2$')
plt.ylabel('$m/(n_1n_2)$')
plt.imshow(ProbForSuccRecSPF[:,:,0],origin='lower', extent=[0.01, 0.3, 0.05, 0.3])
#plt.colorbar()
#title('SPF, Best Approximation')

## Figure 2 - SPF, Discrepancy Principle

plt.figure()
plt.xlabel('$s/n_2$')
plt.ylabel('$m/(n_1n_2)$')
ax2 = plt.imshow(ProbForSuccRecSPF[:,:,1],origin='lower', extent=[0.01, 0.3, 0.05, 0.3])
#plt.colorbar()
#title('SPF, Discrepancy Principle')

## Figure 3 - ATLAS, Best Approximation

plt.figure()
plt.xlabel('$s/n_2$')
plt.ylabel('$m/(n_1n_2)$')
ax3 = plt.imshow(ProbForSuccRecATLAS[:,:,0],origin='lower', extent=[0.01, 0.3, 0.05, 0.3])
#plt.colorbar()
#title('ATLAS, Best Approximation')

## Figure 4 - ATLAS, Discrepancy Principle

plt.figure()
plt.xlabel('$s/n_2$')
plt.ylabel('$m/(n_1n_2)$')
ax4 = plt.imshow(ProbForSuccRecATLAS[:,:,1],origin='lower', extent=[0.01, 0.3, 0.05, 0.3])
#plt.colorbar()
#title('ATLAS, Discrepancy Principle')