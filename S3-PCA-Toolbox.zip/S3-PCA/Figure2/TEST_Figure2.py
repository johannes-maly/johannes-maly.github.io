#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec 18 14:13:13 2020

@author: johannes
@content: Test for Figure 2
"""

import sys
sys.path.append("/Users/johannes/Desktop/Code/PythonCodes/ATLAS")

import numpy as np
import numpy.linalg as la
import random
import ToolsATLAS as TA
import ToolsSPF as TS

import multiprocessing as mp
import joblib as jl


## Define computation

def compute(k,n1,n2,SuccessThreshold,NrMeas,NrOfX):

    ## Dependent Parameters
    
    noise = 0.2
    
    s_grid = np.arange(5,55,5) # np.arange(5,15,5)
    mu_init = 1 # 1
    mu_steps = 10 # 10
    
    s1 = 16
    s2 = np.floor(np.arange(0.01,0.31,0.01)*n2).astype(int) #np.floor(np.arange(0.02,0.52,0.02)*n2).astype(int) #np.floor(np.arange(0.1,0.5,0.05)*n2).astype(int) 
    rank = 3 # 3
    
    ErrorMatrixSPF = np.zeros((len(s2),NrOfX,2))
    ErrorMatrixATLAS = np.zeros((len(s2),NrOfX,2))
    
    N0_AM = 30
    EnetTolerance = 1e-6
    perturb = 0
    
    IS_RECOVERY_ALREADY_SAFE_SPF = False
    IS_RECOVERY_ALREADY_SAFE_ATLAS = False
    
    ## Create Measurements
    
    A = np.random.randn(NrMeas[k],n1*n2)/(NrMeas[k]**0.5)
    
    ## Iterate Sparsity
    ErrorS = np.zeros((len(s2),NrOfX,4))
    for s in np.arange(len(s2)-1,-1,-1): 
    
        if not IS_RECOVERY_ALREADY_SAFE_SPF or not IS_RECOVERY_ALREADY_SAFE_ATLAS:
            
            ErrorX = np.zeros((NrOfX,4))
            for l in range(NrOfX):      
                
                ## Create X with sparse right singular vectors to be recovered (with or without common support)

                #[U,V] = createInput(n1,n2,rank,s1,s2(s),'sparse','orthogonal','joint');
                [U,V] = TA.createInput(n1,n2,rank,s1,s2[s],'l1','arbitrary','arbitrary')
                X = U @ V.T
                normX = la.norm(X,'fro')


                ## Measurement matrix and measurements

                y = A @ np.ndarray.flatten(X)[:,None]
                eps = np.random.rand(len(y),1)
                eps = eps*noise*normX/la.norm(eps)
                y = y+eps
                normy = la.norm(y)


                ## Create start values by taking the singular vector pairs of the rank(X) leading singular values of A'*y

                U0, V0 = TA.init(A, y, U, V, perturbation=0.0,init_type='perturbed')

                ## Recover with SPF and ATLAS and pick optimal parameter
                
                if not IS_RECOVERY_ALREADY_SAFE_SPF:
                    ErrorGridSPF = np.zeros((len(s_grid),2))               
                    for i in range(len(s_grid)): 
                        
                        [Uspf,Vspf] = TS.rSPF(A,y,s1/n1,min(s_grid[i]/n2,1),U0[:,:rank],V0[:,:rank],N0_AM)
                        Xhat = Uspf @ Vspf.T
                        ErrorGridSPF[i,0] = la.norm( X - Xhat,'fro')/normX
                        ErrorGridSPF[i,1] = abs(noise - la.norm( y - A @ np.ndarray.flatten(Xhat)[:,None],'fro')/normy)
                        
                    
                    ErrorX[l,0] = np.amin(ErrorGridSPF[:,0])
                    idx = np.argmin(ErrorGridSPF[:,1])
                    ErrorX[l,1] = ErrorGridSPF[idx,0]
                    
                    if np.sum( np.amax(ErrorX[:,0:2],axis=0) >= SuccessThreshold ) == 0:
                        IS_RECOVERY_ALREADY_SAFE_SPF = True
                
                if not IS_RECOVERY_ALREADY_SAFE_ATLAS:
                    mu = mu_init
                    rel_error_X = rel_error_y = 1
                    muIsOpt_BA = muIsOpt_DP = False
                    for i in range(mu_steps):
                        if not muIsOpt_BA or not muIsOpt_DP:
                            
                            alphaAM = np.array([mu,mu])
                            betaAM = np.array([mu,mu])
                            
                            Uhat_AM, Vhat_AM = TA.ATLAS_AM( y,A,alphaAM,betaAM,U0[:,:rank],V0[:,:rank],N0_AM,EnetTolerance,perturb )
                            Xhat = Uhat_AM @ Vhat_AM.T
                            yhat = A @ np.ndarray.flatten(Xhat)[:,None]
                            
                            if not muIsOpt_BA and rel_error_X < np.minimum(1,la.norm(X - Xhat)/normX):
                                muIsOpt_BA = True
                                mu_BA = mu
                                error_BA = rel_error_X
                            if not muIsOpt_DP and rel_error_y < np.minimum(1,abs(noise - la.norm(y - yhat)/normy)):
                                muIsOpt_DP = True
                                mu_DP = mu
                                error_DP = rel_error_X
                                
                            rel_error_X = np.minimum(1,la.norm(X - Xhat)/normX)
                            rel_error_y = np.minimum(1,abs(noise - la.norm(y - yhat)/normy))
                            mu = 0.5*mu
                            
                    if not muIsOpt_BA:
                        error_BA = rel_error_X
                    if not muIsOpt_DP:
                        error_DP = rel_error_X
                    
                    ErrorX[l,2] = error_BA
                    ErrorX[l,3] = error_DP 
                    
                    if np.sum( np.amax(ErrorX[:,2:],axis=0) >= SuccessThreshold ) == 0:
                        IS_RECOVERY_ALREADY_SAFE_ATLAS = True
                      
            ErrorS[s,:,:] = ErrorX    
    
    
    ErrorMatrixSPF[:,:,0] = ErrorS[:,:,0]
    ErrorMatrixSPF[:,:,1] = ErrorS[:,:,1]
    ErrorMatrixATLAS[:,:,0] = ErrorS[:,:,2]
    ErrorMatrixATLAS[:,:,1] = ErrorS[:,:,3]
    
    return ErrorMatrixSPF, ErrorMatrixATLAS
    

## Parameters

n1 = 16
n2 = 100

SuccessThreshold = 0.4             #Error in % of norm(X) to call approximation successful

NrOfX   = 10 # 20
NrMeas  = np.floor(np.arange(0.05,0.31,0.01)*n1*n2).astype(int) #np.floor(np.arange(0.04,0.52,0.02)*n1*n2).astype(int) # np.floor(np.arange(0.1,0.5,0.05)*n1*n2).astype(int)

random.seed(2)

num_cores = mp.cpu_count()

output = jl.Parallel(n_jobs=num_cores,verbose=40)(jl.delayed(compute)(i,n1,n2,SuccessThreshold,NrMeas,NrOfX) for i in range(len(NrMeas)))

ErrorMatrixSPF = np.array(output)[:,0,:,:,:]
ErrorMatrixATLAS = np.array(output)[:,1,:,:,:]

ProbForSuccRecSPF = np.sum( ErrorMatrixSPF < SuccessThreshold,axis=2 ) / NrOfX
ProbForSuccRecATLAS = np.sum( ErrorMatrixATLAS < SuccessThreshold,axis=2 ) / NrOfX

AverageErrorSPF = np.sum( ErrorMatrixSPF,axis=2 ) / NrOfX
AverageErrorATLAS = np.sum( ErrorMatrixATLAS,axis=2 ) / NrOfX


import pickle
# Saving the objects:
with open('DATA_Figure2.pkl', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([ProbForSuccRecSPF,ProbForSuccRecATLAS,AverageErrorSPF,AverageErrorATLAS], f)


