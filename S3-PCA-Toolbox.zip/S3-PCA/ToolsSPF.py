#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec  3 14:14:20 2020

@author: johannes
@content: auxiliary functions for SPF code
"""

import numpy as np
import math
import numpy.linalg as la
import scipy.linalg as la2


############################################################################
### AltMinSense

def altMinSense( A,y,U0,V0,N_iter ):
    
    n1, r = np.shape(U0)
    n2 = np.shape(V0)[0]
    m = len(y)
    
    U, V = U0, V0
    
    Av = np.zeros((m,n1*r))           ## Av * vec(U) = A * vec(UV')
    Au = np.zeros((m,n2*r))           ## Au * vec(V) = A * vec(UV')
    
    for k in range(N_iter):
        
        ## Create Av and compute U
        for l in np.arange(m):
            TempAv = np.reshape(A[l,:],(n1,n2)) @ V
            Av[l,:] = np.squeeze(np.ndarray.flatten(TempAv))
        
        U = LeastSquares(Av,y,np.arange(n1),n1,r)
        
        ## Create Au and compute V
        for l in np.arange(m):
            TempAu = np.reshape(A[l,:],(n1,n2)).T @ U
            Au[l,:] = np.squeeze(np.ndarray.flatten(TempAu))
        
        V = LeastSquares(Au,y,np.arange(n2),n2,r)
        
    return U, V


############################################################################
### SPF

def rSPF( A,y,s1,s2,U0,V0,N0 ):
    """
        Implementation of SPF
    """
    
    n1,r = U0.shape
    n2 = V0.shape[0]
    m = len(y)
    
    U = U0
    V = V0
    
    Av = np.zeros((m,n1*r))           ## Av * vec(U) = A * vec(UV')
    Au = np.zeros((m,n2*r))           ## Au * vec(V) = A * vec(UV')
    
    #print('\nIterations SPF:')

    for t in np.arange(N0):
        
        #print('|',end='')
        
        ## Orthogonalize V
        V = la2.orth(V)
        if V.shape[1] < r:
            V = np.append(V,np.zeros(n2,r-V.shape[1]),axis=1)
            
        ## Create Av
        for l in np.arange(m):
            TempAv = np.reshape(A[l,:],(n1,n2)) @ V
            Av[l,:] = np.squeeze(np.ndarray.flatten(TempAv))
        
        ## Compute U
        if s1*n1 < n1:
            U = B_HTP(Av,y,math.floor(s1*n1),n1,r,N0) 
        else:
            U = LeastSquares(Av,y,np.arange(n1),n1,r)
        
        
        ## Orthogonalize U
        U = la2.orth(U)
        if U.shape[1] < r:
            U = np.append(U,np.zeros(n1,r-U.shape[1]),axis=1)
            
        ## Create Au
        for l in np.arange(m):
            TempAu = np.reshape(A[l,:],(n1,n2)).T @ U
            Au[l,:] = np.squeeze(np.ndarray.flatten(TempAu))
        
        ## Compute V
        if s2*n2 < n2:
            V = B_HTP(Au,y,math.floor(s2*n2),n2,r,N0)
        else:
            V = LeastSquares(Au,y,np.arange(n2),n2,r)
            
    
    return U,V


############################################################################
### Block HTP


def B_HTP( Phi,y,s,dx1,dx2,N0 ):
    """
    HTP Algorithm for matrices enforcing row-sparsity
    """
    X = np.zeros((dx1,dx2))
    Xnorms = np.zeros((dx1,1)) 
    for k in np.arange(N0):
        
        ## Residual
        Xtemp = X + np.reshape(Phi.T @ ( y - Phi @ np.ndarray.flatten(X)[:,None]),(dx1,dx2))
        
        ## s in norm largest rows
        Xnorms = la.norm(Xtemp,2,axis=1)
        I = np.squeeze(np.argsort(-Xnorms,axis=0))
        J = np.sort(I[:s])
        
        ## solve Least Square problem
        X = LeastSquares(Phi,y,J,dx1,dx2)
        
    return X

 
############################################################################
### Least Squares Function

def LeastSquares( Phi,y,J,dx1,dx2 ):
    """   Solve
    
               X = argmin | y - Phi*X_(:) |_2
               
          where X_ is zero in all rows not in J
    """

    X = np.zeros((dx1,dx2))

    ## Build reduced Phi_J
    Jextended = np.array([])
    for k in np.arange(dx2):
        #Jextended = np.append(Jextended,J+k*dx1)
        Jextended = np.append(Jextended,dx2*(J+1)-k)
    Jextended = np.sort(Jextended-1)    
    #Jextended = np.array(list(set(Jextended)))
        
    Phi_J = Phi[:,Jextended.astype(int)]
    
    ## Solve LS with Phi_J
    X_J = la.lstsq(Phi_J, y,rcond=None)
    X_J = np.reshape(X_J[0],(len(J),dx2))
    
    ## Expand X_J to X
    X[J,:] = X_J
    
    return X