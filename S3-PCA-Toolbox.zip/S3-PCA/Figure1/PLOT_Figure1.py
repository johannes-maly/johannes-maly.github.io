#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 10:15:10 2020

@author: johannes
@content: Plot parameter influence on ATLAS reconstruction
"""

import matplotlib.pyplot as plt

import pickle
# Loading the objects:
with open('DATA_Figure1.pkl', 'rb') as f:  # Python 3: open(..., 'wb')
    #[mu_PALM,Sparsity_PALM,Sparsity_PALM2,EffSparsity_PALM,EffSparsity_PALM2,Error_PALM,Error_PALM2] = pickle.load(f)
    [mu,Error_INIT,Sparsity_AM,Sparsity_AM2,EffSparsity_AM,EffSparsity_AM2,Error_AM,Error_AM2] = pickle.load(f)


Error = Error_AM
Sparsity = Sparsity_AM
EffSparsity = EffSparsity_AM
Error2 = Error_AM2
Sparsity2 = Sparsity_AM2
EffSparsity2 = EffSparsity_AM2

"""
plt.rc('font', size=14)          # controls default text sizes
plt.rc('axes', titlesize=14)     # fontsize of the axes title
plt.rc('axes', labelsize=14)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=10)    # fontsize of the tick labels
plt.rc('ytick', labelsize=10)    # fontsize of the tick labels
plt.rc('legend', fontsize=14)    # legend fontsize
plt.rc('figure', titlesize=14)  # fontsize of the figure title
"""

col = ['r','b','g','p','y']


fig1, ax1 = plt.subplots()
ax1.semilogx(mu,Error,'-',color=col[0],linewidth=2,label='Relative Error')
ax1.semilogx(mu,Error_INIT,'--',color='k',linewidth=1,label='Initial Error')
ax1.semilogx(mu,Sparsity,':',marker='x',color=col[1],linewidth=2,label='Relative Sparsity')
ax1.semilogx(mu,EffSparsity,':',marker='o',color=col[2],linewidth=2,label='Relative Effective Sparsity')

ax1.set_xlabel(r"$\mu$",fontweight='bold')
ax1.set_ylabel("Relative Error / Relative Sparsity",fontweight='bold')
ax1.set_xlim(mu[0],mu[-1])
ax1.legend()

fig2, ax2 = plt.subplots()
ax2.semilogx(mu,Error2,'-',color=col[0],linewidth=2,label='Relative Error')
ax2.semilogx(mu,Error_INIT,'--',color='k',linewidth=1,label='Initial Error')
ax2.semilogx(mu,Sparsity2,':',marker='x',color=col[1],linewidth=2,label='Relative Sparsity')
ax2.semilogx(mu,EffSparsity2,':',marker='o',color=col[2],linewidth=2,label='Relative Effective Sparsity')

ax2.set_xlabel(r"$\mu$",fontweight='bold')
ax2.set_ylabel("Relative Error / Relative Sparsity",fontweight='bold')
ax2.set_xlim(mu[0],mu[-1])
ax2.legend()
