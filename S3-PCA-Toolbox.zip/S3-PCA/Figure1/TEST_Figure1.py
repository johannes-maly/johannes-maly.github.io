#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 09:02:04 2020

@author: johannes
@content: Check parameter influence on ATLAS reconstruction
"""

import sys
sys.path.append("/Users/johannes/Desktop/Code/PythonCodes/ATLAS")

import ToolsATLAS as TA
    
import multiprocessing as mp
import joblib as jl

import numpy as np
import numpy.linalg as la
import math
import random

## Define computation

def compute(i):
    
    ## Dependent Parameters
    
    #mu = np.concatenate((np.arange(1e-4,1e-3,3e-4),np.arange(1e-3,1e-2,3e-3),np.arange(1e-2,1e-1,3e-2),np.arange(1e-1,1e-0,3e-1)))
    mu = np.logspace(-5,0,15)
    
    N0_AM = 30
    EnetTolerance = 1e-6
    perturbation = 0
    
    n1, n2 = (20,300)
    s1, s2 = (20,20)
    m = 160
    rank = 1
    noiseLevel = 0.05
    
    i_type = 'perturbed'
    perturb = 0.4
    
    E_AM = np.zeros(len(mu))
    E_AM2 = np.zeros(len(mu))
    S_AM = np.zeros(len(mu))
    S_AM2 = np.zeros(len(mu))
    ES_AM = np.zeros(len(mu))
    ES_AM2 = np.zeros(len(mu))
    INIT = np.zeros(len(mu))
    
    ## Create X 
    
    #[U,V] = TA.createInput(n1,n2,rank,s1,s2,'sparse','orthogonal','joint');
    [U,V] = TA.createInput(n1,n2,rank,s1,s2,'l1','arbitrary','arbitrary');
    X = U @ V.T
    normX = la.norm(X,'fro')


    ## Measurement matrix and measurements

    A = np.random.normal(0,1,(m,n1*n2))/math.sqrt(m)
    y = A @ np.ndarray.flatten(X)[:,None]
    eps = np.random.rand(len(y),1)
    eps = eps*noiseLevel*normX/la.norm(eps)
    y = y+eps


    ## Create start values by taking the singular vector pairs of the rank(X) leading singular values of A'*y

    U0, V0 = TA.init(A, y, U, V, perturbation=perturb, init_type=i_type)
        

    ## Recover X 
    
    for l in range(len(mu)):
        
        alphaAM = np.array([math.sqrt(s1)*mu[l], mu[l]])
        betaAM = np.array([math.sqrt(s1)*mu[l], math.sqrt(s1/s2)*mu[l]])
        
        alphaAM2 = np.array([mu[l], mu[l]])
        betaAM2 = np.array([mu[l], mu[l]])

        Uhat_AM, Vhat_AM = TA.ATLAS_AM( y,A,alphaAM,betaAM,U0[:,:rank],V0[:,:rank],N0_AM,EnetTolerance,perturbation )
        Uhat_AM2, Vhat_AM2 = TA.ATLAS_AM( y,A,alphaAM2,betaAM2,U0[:,:rank],V0[:,:rank],N0_AM,EnetTolerance,perturbation )
        
        S_AM[l] = np.count_nonzero(np.around(Vhat_AM,decimals=4))/(rank*n2)
        S_AM2[l] = np.count_nonzero(np.around(Vhat_AM2,decimals=4))/(rank*n2)

        ES_AM[l] = la.norm(np.ndarray.flatten(Vhat_AM)[:,None],1)/np.maximum(la.norm(Vhat_AM,'fro'),np.finfo(float).eps)/math.sqrt(rank*n2)
        ES_AM2[l] = la.norm(np.ndarray.flatten(Vhat_AM2)[:,None],1)/np.maximum(la.norm(Vhat_AM2,'fro'),np.finfo(float).eps)/math.sqrt(rank*n2)
        
        E_AM[l] = la.norm( X - Uhat_AM @ Vhat_AM.T ,'fro')/normX
        E_AM2[l] = la.norm( X - Uhat_AM2 @ Vhat_AM2.T ,'fro')/normX
        
        INIT[l] = la.norm( X - U0 @ V0.T ,'fro')/normX
    
    return S_AM, S_AM2, ES_AM, ES_AM2, E_AM, E_AM2, mu, INIT

    

## Independent Parameters

NrOfX = 100

random.seed(2)

num_cores = mp.cpu_count()

output = jl.Parallel(n_jobs=num_cores,verbose=10)(jl.delayed(compute)(i) for i in range(NrOfX))

output_averaged = np.sum(output,axis=0)/NrOfX

Sparsity_AM = output_averaged[0]
Sparsity_AM2 = output_averaged[1]
EffSparsity_AM = output_averaged[2]
EffSparsity_AM2 = output_averaged[3]
Error_AM = output_averaged[4]
Error_AM2 = output_averaged[5]

mu = output_averaged[6]
Error_INIT = output_averaged[7]


import pickle
# Saving the objects:
with open('DATA_Figure1.pkl', 'wb') as f:  # Python 3: open(..., 'wb')
    #pickle.dump([mu_PALM,Sparsity_PALM,Sparsity_PALM2,EffSparsity_PALM,EffSparsity_PALM2,Error_PALM,Error_PALM2], f)
    pickle.dump([mu,Error_INIT,Sparsity_AM,Sparsity_AM2,EffSparsity_AM,EffSparsity_AM2,Error_AM,Error_AM2], f)

    
    