#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Dec 16 08:16:28 2020

@author: johannes
"""

import matplotlib.pyplot as plt
import numpy as np

import pickle
# Loading the objects:
with open('DATA_Figure3.pkl', 'rb') as f:  # Python 3: open(..., 'wb')
    [m_Range_Gaus,m_Range_Rank, Error_Init_Gaus, Error_Init_Rank, Error_Gaus,Error_Heav,Error_Rank,Error_LR_Gaus,Error_LR_Heav,Error_LR_Rank,Mu_Gaus,Mu_Heav,Mu_Rank] = pickle.load(f)

col = ['r','b','g','p','y']

## Plot Error (Gaus + Heav)

fig1, ax1 = plt.subplots()
ax1.plot(m_Range_Gaus,Error_Gaus,'-',color=col[0],linewidth=2,label='Gaussian - S3PCA')
ax1.plot(m_Range_Gaus,Error_LR_Gaus,'--',color=col[0],linewidth=2,label='Gaussian - AltMinSense')
ax1.plot(m_Range_Gaus,Error_Heav,'-',marker='x',color=col[1],linewidth=2,label='Heavy Tailed - S3PCA')
ax1.plot(m_Range_Gaus,Error_LR_Heav,'--',marker='x',color=col[1],linewidth=2,label='Heavy Tailed - AltMinSense')
ax1.plot(m_Range_Gaus,Error_Init_Gaus,'--',color='black',linewidth=1,label='Initialization')

ax1.set_xlabel("Number of Measurements",fontweight='bold')
ax1.set_ylabel("Relative Error",fontweight='bold')
ax1.set_xlim(m_Range_Gaus[0],m_Range_Gaus[-1])
ax1.legend()


## Plot Error (Rank)

fig2, ax2 = plt.subplots()
ax2.plot(m_Range_Rank,Error_Rank,'-',color=col[0],linewidth=2,label='Rank-1 - S3PCA')
ax2.plot(m_Range_Rank,Error_LR_Rank,'--',color=col[0],linewidth=2,label='Rank-1 - AltMinSense')
ax2.plot(m_Range_Rank,Error_Init_Rank,'--',color='black',linewidth=1,label='Initialization')

ax2.set_xlabel("Number of Measurements",fontweight='bold')
ax2.set_ylabel("Relative Error",fontweight='bold')
ax2.set_xlim(m_Range_Rank[0],m_Range_Rank[-1])
ax2.legend()

## Plot Parameter (Gaus + Heav)

fig3, ax3 = plt.subplots()
ax3.plot(m_Range_Gaus,Mu_Gaus,'-',color=col[0],linewidth=3,label='Gaussian')
ax3.plot(m_Range_Gaus,Mu_Heav,'-',marker='x',color=col[1],linewidth=3,label='Heavy Tailed')

ax3.set_xlabel("Number of Measurements")
ax3.set_ylabel(r"$\mu$")
ax3.set_xlim(m_Range_Gaus[0],m_Range_Gaus[-1])
ax3.legend()

## Plot Parameter (Rank)

fig3, ax3 = plt.subplots()
ax3.plot(m_Range_Rank,Mu_Rank,'-',color=col[0],linewidth=3,label='Rank-1')

ax3.set_xlabel("Number of Measurements")
ax3.set_ylabel(r"$\mu$")
ax3.set_xlim(m_Range_Rank[0],m_Range_Rank[-1])
ax3.legend()