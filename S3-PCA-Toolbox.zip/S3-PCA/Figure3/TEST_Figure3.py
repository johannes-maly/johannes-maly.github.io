#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 10 11:08:24 2020

@author: johannes
@content: Check ATLAS for different measurement set-ups
"""

import sys
sys.path.append("/Users/johannes/Desktop/Code/PythonCodes/ATLAS")

import ToolsATLAS as TA
import ToolsSPF as TS
    
import multiprocessing as mp
import joblib as jl

import numpy as np
import numpy.linalg as la
import math
import random


## Define computation

def compute(i):
    
    ## Dependent Parameters
    
    mu_init_Gaus, mu_init_Heav, mu_init_Rank = 1, 500, 2
    mu_steps = 10
    N0_AM = 30
    EnetTol = 1e-6
    
    rank = 1
    n1_Gaus, n2_Gaus = (20,300)
    s1_Gaus, s2_Gaus = (20,20)
    m_Min_Gaus = rank*(s1_Gaus+s2_Gaus)
    n1_Rank, n2_Rank = (50,50)
    s1_Rank, s2_Rank = (10,10)
    m_Min_Rank = rank*(s1_Rank+s2_Rank)
    
    noiseLevel = 0.1
    m_Range_Gaus = np.arange(1*m_Min_Gaus,6*m_Min_Gaus,5)
    m_Range_Rank = np.arange(1*m_Min_Rank,6*m_Min_Rank,5)
    
    i_type = 'perturbed'
    perturb = 0.4
    
    Error_Init_Gaus = np.zeros((len(m_Range_Gaus),1))
    Error_Init_Rank = np.zeros((len(m_Range_Rank),1))
    
    Error_Gaus = np.zeros((len(m_Range_Gaus),1))
    Error_Heav = np.zeros((len(m_Range_Gaus),1))
    Error_Rank = np.zeros((len(m_Range_Rank),1))
    
    Error_LR_Gaus = np.zeros((len(m_Range_Gaus),1))
    Error_LR_Heav = np.zeros((len(m_Range_Gaus),1))
    Error_LR_Rank = np.zeros((len(m_Range_Rank),1))
    
    Mu_Gaus = np.zeros((len(m_Range_Gaus),1))
    Mu_Heav = np.zeros((len(m_Range_Gaus),1))
    Mu_Rank = np.zeros((len(m_Range_Rank),1))
    
    
    ## Create X 
    
    [U_Gaus,V_Gaus] = TA.createInput(n1_Gaus,n2_Gaus,rank,s1_Gaus,s2_Gaus,'l1','arbitrary','arbitrary');
    X_Gaus = U_Gaus @ V_Gaus.T
    normX_Gaus = la.norm(X_Gaus,'fro')
    [U_Rank,V_Rank] = TA.createInput(n1_Rank,n2_Rank,rank,s1_Rank,s2_Rank,'l1','arbitrary','arbitrary');
    X_Rank = U_Rank @ V_Rank.T
    normX_Rank = la.norm(X_Rank,'fro')
    
    for m in range(len(m_Range_Gaus)):
        
        ## Measurement matrices and measurements
        
        eps = np.random.rand(m_Range_Gaus[m],1)
        eps = eps*noiseLevel*normX_Gaus/la.norm(eps)
    
        ## Gaussian
        A_Gaus = np.random.normal(0,1,(m_Range_Gaus[m],n1_Gaus*n2_Gaus))/math.sqrt(m_Range_Gaus[m])
        y_Gaus = A_Gaus @ np.ndarray.flatten(X_Gaus)[:,None] + eps
        
        ## Heavy-Tailed
        A_Heav = np.exp(np.random.normal(0,1,(m_Range_Gaus[m],n1_Gaus*n2_Gaus)))
        A_Heav = A_Heav * np.sign(np.random.normal(0,1,(m_Range_Gaus[m],n1_Gaus*n2_Gaus)))
        y_Heav = A_Heav @ np.ndarray.flatten(X_Gaus)[:,None] + eps
                                             
        ## Create init
        
        U0, V0 = TA.init(A_Gaus, y_Gaus, U_Gaus, V_Gaus, perturbation=perturb, init_type=i_type)
        
        ## Reconstruction + Parameter Estimation
        mu_opt_Gaus = mu_init_Gaus
        mu_opt_Heav = mu_init_Heav
        err_opt_Gaus = err_opt_Heav =  1
        GausIsOpt = HeavIsOpt = False
        
        for l in range(mu_steps):
            
            if not GausIsOpt:
                
                alpha = np.array([mu_opt_Gaus,mu_opt_Gaus])
                beta = np.array([mu_opt_Gaus,mu_opt_Gaus])
                Uhat_Gaus, Vhat_Gaus = TA.ATLAS_AM(y_Gaus, A_Gaus, alpha, beta, U0[:,:rank], V0[:,:rank], N0_AM, EnetTol, 0)
                
                relError = np.minimum(1,la.norm( X_Gaus - Uhat_Gaus @ Vhat_Gaus.T ,'fro')/normX_Gaus)
                
                if relError > err_opt_Gaus:
                    GausIsOpt = True
                else:
                    err_opt_Gaus = relError
                    mu_opt_Gaus = 0.5 * mu_opt_Gaus
                    
                    
            if not HeavIsOpt:
                
                alpha = np.array([mu_opt_Heav,mu_opt_Heav])
                beta = np.array([mu_opt_Heav,mu_opt_Heav])
                Uhat_Heav, Vhat_Heav = TA.ATLAS_AM(y_Heav, A_Heav, alpha, beta, U0[:,:rank], V0[:,:rank], N0_AM, EnetTol, 0)
                
                relError = np.minimum(1,la.norm( X_Gaus - Uhat_Heav @ Vhat_Heav.T ,'fro')/normX_Gaus)
                
                if relError > err_opt_Heav:
                    HeavIsOpt = True
                else:
                    err_opt_Heav = relError
                    mu_opt_Heav = 0.5 * mu_opt_Heav
                    
        
        ## Compute Low-Rank Estimate
        
        Uhat_LR_Gaus, Vhat_LR_Gaus = TS.altMinSense( A_Gaus,y_Gaus,U0[:,:rank],V0[:,:rank],N0_AM )
        Uhat_LR_Heav, Vhat_LR_Heav = TS.altMinSense( A_Heav,y_Heav,U0[:,:rank],V0[:,:rank],N0_AM )
        
        Error_Init_Gaus[m] = la.norm( X_Gaus - U0[:,:rank] @ V0[:,:rank].T )/la.norm(X_Gaus)
        Error_Gaus[m] = err_opt_Gaus
        Error_Heav[m] = err_opt_Heav
        Error_LR_Gaus[m] = np.minimum(1,la.norm(X_Gaus - Uhat_LR_Gaus @ Vhat_LR_Gaus.T)/la.norm(X_Gaus))
        Error_LR_Heav[m] = np.minimum(1,la.norm(X_Gaus - Uhat_LR_Heav @ Vhat_LR_Heav.T)/la.norm(X_Gaus))
    
        Mu_Gaus[m] = mu_opt_Gaus
        Mu_Heav[m] = mu_opt_Heav
        
    for m in range(len(m_Range_Rank)):
        
        ## Measurement matrices and measurements
        
        eps = np.random.rand(m_Range_Rank[m],1)
        eps = eps*noiseLevel*normX_Rank/la.norm(eps)
        
        ## Rank-1
        A_Rank = np.zeros((m_Range_Rank[m],n1_Rank*n2_Rank))
        A = np.random.normal(0,1,(n1_Rank,m_Range_Rank[m]))
        for i in range(m_Range_Rank[m]):
            A_Rank[i,:] = np.ndarray.flatten(np.outer(A[:,i],A[:,i]))
        y_Rank = A_Rank @ np.ndarray.flatten(X_Rank)[:,None] + eps
                                             
        ## Create init
        
        U0, V0 = TA.init(A_Rank, y_Rank, U_Rank, V_Rank, perturbation=perturb, init_type=i_type)
        
        ## Reconstruction + Parameter Estimation
        mu_opt_Rank = mu_init_Rank
        err_opt_Rank = 1
        RankIsOpt = False
        
        for l in range(mu_steps):
                
            if not RankIsOpt:
                
                alpha = np.array([mu_opt_Rank,mu_opt_Rank])
                beta = np.array([mu_opt_Rank,mu_opt_Rank])
                Uhat_Rank, Vhat_Rank = TA.ATLAS_AM(y_Rank, A_Rank, alpha, beta, U0[:,:rank], V0[:,:rank], N0_AM, EnetTol, 0)
                
                relError = np.minimum(1,la.norm( X_Rank - Uhat_Rank @ Vhat_Rank.T ,'fro')/normX_Rank)
                
                if relError > err_opt_Rank:
                    RankIsOpt = True
                else:
                    mu_opt_Rank = 0.5 * mu_opt_Rank
                    err_opt_Rank = relError
                    
        ## Compute Low-Rank Estimate
        
        Uhat_LR_Rank, Vhat_LR_Rank = TS.altMinSense( A_Rank,y_Rank,U0[:,:rank],V0[:,:rank],N0_AM )
        
        
        Error_Init_Rank[m] = la.norm( X_Rank - U0[:,:rank] @ V0[:,:rank].T )/la.norm(X_Rank)
        Error_Rank[m] = err_opt_Rank
        Error_LR_Rank[m] = np.minimum(1,la.norm(X_Rank - Uhat_LR_Rank @ Vhat_LR_Rank.T)/la.norm(X_Rank))
    
        Mu_Rank[m] = mu_opt_Rank
        
        
    return m_Range_Gaus, m_Range_Rank, Error_Init_Gaus, Error_Init_Rank, Error_Gaus, Error_Heav, Error_Rank, Error_LR_Gaus, Error_LR_Heav, Error_LR_Rank, Mu_Gaus, Mu_Heav, Mu_Rank



## Independent Parameters

NrOfX = 100

random.seed(2)

num_cores = mp.cpu_count()

output = jl.Parallel(n_jobs=num_cores,verbose=10)(jl.delayed(compute)(i) for i in range(NrOfX))

output_averaged = np.sum(output,axis=0)/NrOfX

m_Range_Gaus = output_averaged[0]
m_Range_Rank = output_averaged[1]

Error_Init_Gaus = output_averaged[2]
Error_Init_Rank = output_averaged[3]
Error_Gaus = output_averaged[4]
Error_Heav = output_averaged[5]
Error_Rank = output_averaged[6]
Error_LR_Gaus = output_averaged[7]
Error_LR_Heav = output_averaged[8]
Error_LR_Rank = output_averaged[9]

Mu_Gaus = output_averaged[10]
Mu_Heav = output_averaged[11]
Mu_Rank = output_averaged[12]

import pickle
# Saving the objects:
with open('DATA_Figure3.pkl', 'wb') as f:  # Python 3: open(..., 'wb')
    pickle.dump([m_Range_Gaus,m_Range_Rank, Error_Init_Gaus, Error_Init_Rank, Error_Gaus,Error_Heav,Error_Rank,Error_LR_Gaus,Error_LR_Heav,Error_LR_Rank,Mu_Gaus,Mu_Heav,Mu_Rank], f)

